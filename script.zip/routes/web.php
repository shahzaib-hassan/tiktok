<?php

use Laravel\Lumen\Routing\Router;

/** @var Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/


$router->group([
    'namespace' => 'Api',
    'prefix' => '/api'
], function (Router $router) {
    $router->post('/login', [
        'as' => 'login',
        'uses' => 'AuthController@login',
    ]);
    $router->get('/me', [
        'as' => 'me',
        'uses' => 'AuthController@me',
    ]);

    $router->post('/logout', [
        'as' => 'logout',
        'uses' => 'AuthController@logout',
    ]);

    $router->get('/v1/tiktok-video', [
        'uses' => 'TikTokVideoController@index'
    ]);

    $router->get('/v1/tiktok-video/nwm', [
        'uses' => 'TikTokVideoController@fetchNwm'
    ]);
});

$router->group([
    'namespace' => 'Api',
    'prefix' => '/api',
    'middleware' => 'auth:api'
], function (Router $router) {
    $router->get('/recent', [
        'as' => 'recent',
        'uses' => 'DashboardController@recent',
    ]);
    $router->get('/trending', [
        'as' => 'trending',
        'uses' => 'DashboardController@trending',
    ]);

    $router->post('/settings', [
        'as' => 'settings',
        'uses' => 'SettingsController@store',
    ]);

    $router->get('/proxies', [
        'as' => 'proxies',
        'uses' => 'ProxiesController@index',
    ]);

    $router->post('/proxies', [
        'uses' => 'ProxiesController@store',
    ]);

    $router->delete('/proxies', [
        'uses' => 'ProxiesController@destroy',
    ]);

    $router->post('/account', [
        'uses' => 'AccountController@store'
    ]);

    $router->post('/menus', [
        'uses' => 'MenusController@store'
    ]);

    $router->post('/code-blocks', [
        'uses' => 'CodeBlocksController@store'
    ]);

    $router->post('/pages/image-upload', [
        'uses' => 'PagesController@storeImage'
    ]);

    $router->post('/pages', [
        'uses' => 'PagesController@store'
    ]);

    $router->post('/pages/{slug}', [
        'uses' => 'PagesController@update'
    ]);
});

$router->get('/download', [
    'uses' => 'DownloadController@handle'
]);

$router->get('/video/{id}', [
    'as' => 'app.index',
    'uses' => 'AppController@video',
]);

$router->get('/sitemap.xml', [
    'as' => 'sitemap',
    'uses' => 'SitemapController@index'
]);

$router->get('{any:.*}', [
    'as' => 'home',
    'uses' => 'AppController@index',
]);


