<?php

use Illuminate\Support\Facades\File;
use Laravel\Lumen\Routing\Router;

/** @var Router $router */

$router->group([
    'prefix' => '/api'
], function (Router $router) {

    $router->post('/install', [
        'uses' => 'InstallController@handle'
    ]);


    $router->post('/upgrade', [
        'uses' => 'UpgradeController@handle'
    ]);

});

$router->get('/', function () {

    if (File::isDirectory(base_path('/upgrade')) &&
        $files = File::files(base_path("/upgrade"))) {
        if (count($files) > 0) {
            return redirect()->route('upgrade');
        }
    }

    return redirect()->route('install');
});

$router->get('/install', [
    'uses' => 'InstallController@index',
    'as' => 'install'
]);

$router->get('/upgrade', [
    'uses' => 'UpgradeController@index',
    'as' => 'upgrade'
]);
