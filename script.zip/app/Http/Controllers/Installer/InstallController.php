<?php

namespace App\Http\Controllers\Installer;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class InstallController extends Controller
{

    use InstallableTrait;

    public function index()
    {
        return view("install");
    }

    /**
     * @throws ValidationException
     */
    public function handle(Request $request): JsonResponse
    {
        $this->validate($request, [
            'app' => ['required', 'array'],
            'app.name' => ['required', 'string'],
            'app.url' => ['required', 'string'],
            'db' => ['required', 'array'],
            'db.driver' => ['required', 'string', 'in:mysql,pgsql'],
            'db.host' => ['required', 'string'],
            'db.port' => ['required', 'numeric'],
            'db.database' => ['required', 'string'],
            'db.username' => ['required', 'string'],
            'db.password' => ['string'],
            'db.prefix' => ['string'],
            'user' => ['required', 'array'],
            'user.f_name' => ['required', 'string'],
            'user.l_name' => ['required', 'string'],
            'user.email' => ['required', 'string'],
            'user.password' => ['required', 'string'],
            'license' => ['required', 'string', 'uuid']
        ]);

        try {

            $this->validateLicense($request);

            $dbConfig = $this->getDbConfig($request);
            if (!$this->reconnectAndVerify($dbConfig)) {
                return response()->json(['message' => $this->exception->getMessage()], 500);
            }

            $this->createEnv($this->getRequest($request), $dbConfig);

            Artisan::call('migrate:fresh --seed --force');

            User::updateOrCreate(['email' => $request->input('user.email')], [
                'fname' => $request->input('user.f_name'),
                'lname' => $request->input('user.l_name'),
                'password' => Hash::make($request->input('user.password')),
                'role' => 'admin'
            ]);

            $this->generateJWTSecret();

            setting([
                'menus' => '[{"id":0,"text":"How to Download","link":"how-to-download","external":false},{"id":1,"text":"Terms of Services","link":"terms-of-services","external":false},{"id":2,"text":"Privacy Policy","link":"privacy-policy","external":false}]'
            ])->save();

        } catch (Exception $e) {
            $this->deleteEnv();
            return response()->json(['message' => $e->getMessage()], 500);
        }

        return response()->json(['message' => 'Installation Completed.']);
    }


    protected function getRequest(Request $request): array
    {
        return [
            'app' => [
                'name' => $request->input('app.name'),
                'url' => $request->input('app.url'),
                'desc' => "TikTok Video Downloader Without watermark! Now you can download TikTok Videos without any restriction. Just paste your TikTok Video Url and download the video.",
                "keywords" => "TikTok, TikTok Downloader, TikTok Video Downloader, Download TikTok Videos, Online TikTok Video Downloader, Download TikTok Videos Without Watermark"
            ],
            'db' => [
                'driver' => $request->input('db.driver')
            ],
            'license' => $request->input('license'),
        ];
    }
}
