<?php

namespace App\Http\Controllers\Installer;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class UpgradeController extends Controller
{
    use InstallableTrait;

    public function index()
    {
        return view("upgrade", ['db' => $this->getOldDbConfig()]);
    }

    /**
     * @throws ValidationException
     */
    public function handle(Request $request): JsonResponse
    {

        $this->validate($request, [
            'license' => ['required', 'string', 'uuid'],
            'app' => ['required', 'array'],
            'app.url' => ['required', 'string'],
            'db' => ['required', 'array'],
            'db.driver' => ['required', 'string', 'in:mysql,pgsql'],
            'db.host' => ['required', 'string'],
            'db.port' => ['required', 'numeric'],
            'db.database' => ['required', 'string'],
            'db.username' => ['required', 'string'],
            'db.password' => ['string'],
            'db.prefix' => ['string'],
            'user' => ['required', 'array'],
            'user.email' => ['required', 'string'],
            'user.password' => ['required', 'string']
        ]);

        try {

            $this->validateLicense($request);

            $dbConfig = $this->getDbConfig($request);
            if (!$this->reconnectAndVerify($dbConfig)) {
                return response()->json(['message' => $this->exception->getMessage()], 500);
            }

            $this->createEnv($this->getRequest($request), $dbConfig);

            $this->updateUser($request);

            $this->migrateConfig();

            $this->generateJWTSecret();

        } catch (Exception $exception) {
            $this->deleteEnv();
            return response()->json(['message' => $exception->getMessage()], 500);
        }

        return response()->json(['message' => 'Upgrade Completed.']);
    }

    /**
     * @throws Exception
     */
    protected function updateUser(Request $request)
    {
        /** @var User $user */
        $user = User::where('email', $request->input('user.email'))->first();
        if (!$user) {
            throw new Exception("The user with email [{$request->input('user.email')}] does not exist.");
        }

        $user->password = Hash::make($request->input('user.password'));
        $user->save();
    }

    protected function getOldDbConfig(): array
    {
        if (!File::exists(base_path('/upgrade/database.php')))
            return [];
        return include base_path('/upgrade/database.php') ?? [];
    }

    protected function getRequest(Request $request): array
    {
        $app = include base_path('/upgrade/app.php');

        return [
            'app' => [
                'name' => $app['name'],
                'url' => $request->input('app.url'),
                'desc' => $app['desc'],
                'keywords' => $app['keywords'],
            ],
            'license' => $request->input('license'),
            'db' => [
                'driver' => $request->input('db.driver')
            ]
        ];
    }

    protected function migrateConfig()
    {
        $code = include base_path("/upgrade/code.php");
        $menus = include base_path("/upgrade/menu.php");
        $proxies = include base_path("/upgrade/proxy.php");
        $socials = include base_path("/upgrade/social.php");

        setting([
            'codeBlocks' => json_encode([
                'ads' => array_values($code['ads']) ?? [],
                'headerCodeBlock' => $code['code'] ?? ''
            ]),
            'menus' => json_encode(array_values($menus) ?? []),
            'proxies' => json_encode(array_values($proxies) ?? []),
            'socials' => json_encode(array_values($socials) ?? []),
        ])->save();

    }
}
