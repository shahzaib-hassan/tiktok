<?php

namespace App\Http\Controllers\Installer;

use Exception;
use Illuminate\Encryption\Encrypter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Http;

trait InstallableTrait
{

    /**
     * @var Exception
     */
    protected $exception = null;

    protected function getDbConfig(Request $request): array
    {
        $connection = $request->input('db.driver', 'mysql');
        $config = config("database.connections.$connection");

        return [
            "host" => $request->input('db.host'),
            "port" => $request->input('db.port'),
            "driver" => $config['driver'],
            "database" => $request->input("db.database"),
            "username" => $request->input("db.username"),
            "password" => $request->input("db.password", ''),
            'prefix' => $request->input('db.prefix', '')
        ];
    }

    protected function reconnectAndVerify(array $config): bool
    {
        $connection = config('database.default', 'mysql');

        try {
            //Setting new configs
            Config::set("database.connections.$connection", $config);
            //Removing old connection from list
            DB::purge($connection);
            //Reconnecting
            DB::reconnect($connection);
            //Check the connection
            DB::connection()->getPdo();
            //Returning true if config is valid
            return true;
        } catch (Exception $exception) {
            $this->exception = $exception;
            //Return false
            return false;
        }
    }

    /**
     * @throws Exception
     */
    protected function createEnv(array $request, array $dbConfig)
    {
        $key = 'base64:' . base64_encode(
                Encrypter::generateKey(config('app.cipher'))
            );

        $map = [
            '$APP_NAME' => data_get($request, 'app.name'),
            '$APP_URL' => data_get($request, 'app.url'),
            '$APP_DESC' => data_get($request, 'app.desc'),
            '$APP_KEYWORDS' => data_get($request, 'app.keywords'),
            '$APP_KEY' => $key,
            '$APP_LICENSE' => data_get($request, 'license'),
            '$DB_CONNECTION' => data_get($request, 'db.driver'),
            '$DB_HOST' => $dbConfig['host'],
            '$DB_PORT' => $dbConfig['port'],
            '$DB_DATABASE' => $dbConfig['database'],
            '$DB_USERNAME' => $dbConfig['username'],
            '$DB_PASSWORD' => $dbConfig['password'],
            '$DB_PREFIX' => $dbConfig['prefix'],
            '$APP_INSTALLED' => 'true'
        ];

        $env = File::get(base_path('.env.example'));

        $env = str_replace(array_keys($map), array_values($map), $env);
        if (!File::put(base_path('.env'), $env)) {
            throw new Exception("Unable to write to .env file. Please make sure you have set proper write permissions.");
        }
    }

    protected function generateJWTSecret()
    {
        Artisan::call("jwt:secret");
    }

    protected function deleteEnv()
    {
        if (File::exists(base_path('.env')))
            File::delete(base_path('.env'));
    }

    /**
     * @throws Exception
     */
    protected function validateLicense(Request $request)
    {
        $endpoint = "https://licenser.codespikex.com/api/v1/validate";
        $query = $this->createValidateQuery($request);

        $response = Http::timeout(60)
            ->get($endpoint . '?' . $query);

        $body = $response->json();
        if ($body['status'] != 200) {
            throw new Exception($body['error'] ?? 'License is invalid.');
        }
    }

    protected function createValidateQuery(Request $request): string
    {
        return http_build_query([
            'type' => 'verify',
            'license' => $request->get('license'),
            'ip' => $request->ip(),
            'domain' => $request->input('app.url'),
            'comment' => 'Activate License'
        ]);
    }
}
