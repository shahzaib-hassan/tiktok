<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\VideoResource;
use App\Models\Video;
use App\Repository\TikTokVideo;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class TikTokVideoController extends Controller
{
    /**
     * @throws ValidationException
     */
    public function index(Request $request): JsonResponse
    {
        $this->validate($request, ['url' => ['required', 'string']]);
        $repo = TikTokVideo::find($request->get('url'));
        if (!$repo) {

            $msg = 'Unable to fetch the video.';

            if (TikTokVideo::getException() instanceof \InvalidArgumentException) {
                $msg .= " URL is invalid.";
            } else if (TikTokVideo::getException() instanceof ConnectionException) {
                $msg .= " The video may be private or not available.";
            } else {
                $msg .= " Please try again later.";
            }

            return response()->json(['message' => $msg], 500);
        }

        $model = $repo->toModel();

        /** @var Video $videoModel */
        if ($videoModel = Video::where('video_id', $model->video_id)->first()) {

            $attributes = $model->only([
                'url', 'url_nwm', 'user', 'stats', 'cover', 'caption', 'title',
                'music'
            ]);
            $model = $videoModel;
            foreach ($attributes as $key => $value) {
                $model->setAttribute($key, $value);
            }

            $model->dl_count++;
        }

        $model->save();

        return response()->json(['video' => VideoResource::make($model)]);
    }

    /**
     * @throws ValidationException
     */
    public function fetchNwm(Request $request)
    {
        $this->validate($request, [
            'url' => ['required', 'string', 'url'],
            'id' => ['required', 'numeric']
        ]);

        $original_url = TikTokVideo::findNwmUrl($request->get('url'));
        return response(compact('original_url'));
    }
}
