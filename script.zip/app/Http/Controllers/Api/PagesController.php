<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PagesResource;
use App\Models\Page;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PagesController extends Controller
{
    use IsAdminTrait;

    /**
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $page = new Page;

        $pageFields = $this->validate($request, [
            'title' => ['required', 'string'],
            'slug' => ['required', 'string', Rule::unique($page->getTable(), 'slug')],
            'excerpt' => ['required', 'string'],
            'body' => ['required', 'string'],
        ]);

        $page->update($pageFields);
        $page->fresh();

        return response()->json(['page' => new PagesResource($page)]);
    }

    /**
     * @throws ValidationException
     */
    public function update(Request $request, string $slug): JsonResponse
    {
        /** @var Page $page */
        $page = Page::where('slug', $slug)->firstOrFail();

        $pageFields = $this->validate($request, [
            'title' => ['required', 'string'],
            'slug' => ['required', 'string', Rule::unique($page->getTable(), 'slug')->ignore($slug, 'slug')],
            'excerpt' => ['required', 'string'],
            'body' => ['required', 'string'],
        ]);

        $page->update($pageFields);

        return response()->json(['page' => new PagesResource($page)]);
    }

    /**
     * @throws ValidationException
     */
    public function storeImage(Request $request): JsonResponse
    {
        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $this->validate($request, ['image' => ['required', 'image']]);

        $original_filename = $request->file('image')->getClientOriginalName();
        $original_filename_arr = explode('.', $original_filename);
        $file_ext = end($original_filename_arr);
        $destination_path = public_path('/uploads/');
        $image = 'U-' . time() . '.' . $file_ext;

        if ($request->file('image')->move($destination_path, $image)) {
            $url = '/uploads/' . $image;
            return response()->json(['image' => $url]);
        } else {
            return response()->json(['message' => 'Unable to upload file.'], 500);
        }
    }
}
