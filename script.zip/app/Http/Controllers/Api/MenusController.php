<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class MenusController extends Controller
{
    use IsAdminTrait;

    /**
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $form = $this->validate($request, [
            'menus' => ['array'],
            'menus.*.external' => ['boolean'],
            'menus.*.id' => ['numeric'],
            'menus.*.link' => [],
            'menus.*.text' => ['string'],
        ]);

        setting(['menus' => json_encode($form['menus'])])->save();

        return response()->json(['message' => 'Updated.']);
    }
}
