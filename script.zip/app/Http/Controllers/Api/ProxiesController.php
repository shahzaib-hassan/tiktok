<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Repository\Proxies;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ProxiesController extends Controller
{
    use IsAdminTrait;

    public function index(): JsonResponse
    {
        if (!$this->isAdmin())
            return response()->json(['proxies' => []]);

        $proxies = Proxies::get();

        return response()->json(compact('proxies'));
    }

    /**
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        if (!$this->isAdmin())
            return $this->forbiddenResponse();

        $this->validate($request, ['proxy' => 'required', 'string']);

        if (!$request->boolean('forced', false) && !Proxies::isValidProxy($request->get('proxy'))) {
            return response()->json(['message' => 'Proxy is invalid.'], 500);
        }

        Proxies::push($request->get('proxy'));

        return response()->json(['message' => 'Proxy added.'], 201);
    }

    /**
     * @throws ValidationException
     */
    public function destroy(Request $request): JsonResponse
    {
        if (!$this->isAdmin())
            return $this->forbiddenResponse();

        $this->validate($request, ['proxy' => ['required', 'string']]);
        Proxies::remove($request->get('proxy'));

        return response()->json(['message' => 'Proxy deleted.']);
    }
}
