<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class CodeBlocksController extends Controller
{
    use IsAdminTrait;

    /**
     * @throws ValidationException
     */
    public function store(Request $request): \Illuminate\Http\JsonResponse
    {
        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $form = $this->validate($request, [
            'headerCodeBlock' => ['string'],
            'ads' => ['array'],
            'ads.*.code' => ['string'],
            'ads.*.name' => ['string'],
            'ads.*.network' => ['string'],
            'ads.*.status' => ['string'],
        ]);

        setting([
            'codeBlocks' => json_encode([
                'headerCodeBlock' => base64_decode($form['headerCodeBlock']),
                'ads' => $form['ads']
            ])
        ])->save();

        return response()->json(['message' => 'Updated.']);
    }
}
