<?php

namespace App\Http\Controllers\Api;

use App\Models\User;

trait IsAdminTrait
{
    protected function isAdmin(): bool
    {
        /** @var User $user */
        $user = auth()->user();
        return $user->isAdmin;
    }

    protected function forbiddenResponse(): \Illuminate\Http\JsonResponse
    {
        return response()->json(['message' => ['Forbidden']], 403);
    }
}
