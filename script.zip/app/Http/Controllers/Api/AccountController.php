<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AccountController extends Controller
{
    use IsAdminTrait;

    /**
     * @throws ValidationException
     */
    public function store(Request $request): \Illuminate\Http\JsonResponse
    {

        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $this->validate($request, [
            'email' => ['required', 'string'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        /** @var User $user */
        $user = auth()->user();
        $user->update([
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password'))
        ]);

        return response()->json(compact('user'));
    }
}
