<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class SettingsController extends Controller
{
    use IsAdminTrait;

    /**
     * @throws ValidationException
     */
    public function store(Request $request): JsonResponse
    {
        if (!$this->isAdmin()) {
            return $this->forbiddenResponse();
        }

        $form = $this->validate($request, [
            'app' => ['required', 'array'],
            'app.name' => ['required', 'string'],
            'app.desc' => ['required', 'string'],
            'app.keywords' => ['required', 'string'],
            'app.api_version' => ['required', 'string', 'in:wrapper'],
            'socials' => ['array'],
            'socials.*.text' => ['string'],
            'socials.*.link' => ['string'],
        ], [], [
            'app.name' => 'site name',
            'app.desc' => 'site description',
            'app.keywords' => 'site keywords',
        ]);

        setting([
            'socials' => json_encode($form['socials']),
            'site' => json_encode($form['app'])
        ])->save();

        return response()->json(['message' => 'Updated']);
    }
}
