<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Video;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function recent(Request $request): JsonResponse
    {
        $videos = $this->paginate(Video::recent(), $request)->get();
        return response()->json(compact('videos'));
    }

    public function trending(Request $request): JsonResponse
    {
        $videos = $this->paginate(Video::trending(), $request)->get();
        return response()->json(compact('videos'));
    }

    protected function paginate(Builder $query, Request $request): Builder
    {
        $limit = $request->get('perPage', 30);
        $page = (int)$request->get('page', 1);
        $offset = (($page > 0 ? $page : 1) - 1) * $limit;
        return $query->limit($limit)->offset($offset);
    }
}
