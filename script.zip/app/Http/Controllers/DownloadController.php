<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\StreamedResponse;

class DownloadController extends Controller
{
    /**
     * @throws ValidationException
     */
    public function handle(Request $request): StreamedResponse
    {
        $this->validate($request, [
            'url' => ['required', 'string', 'url'],
            'fileName' => ['required', 'string'],
            'type' => ['required', 'string', 'in:video'],
        ]);

        $response = response()->stream(function () use ($request) {
            echo file_get_contents($request->get('url'));
        });

        $fileName = $request->get('fileName');

        $disposition = $response->headers->makeDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            $fileName,
            str_replace('%', '', Str::ascii($fileName))
        );

        $response->headers->set('Content-Disposition', $disposition);
        $response->headers->set('Content-Type', 'video/mp4');

        return $response;
    }
}
