<?php

namespace App\Http\Controllers;

use App\Http\Resources\PagesResource;
use App\Models\Page;
use App\Models\Video;

class AppController extends Controller
{
    public function index()
    {
        $this->share();
        return view('app');
    }

    public function video(string $id)
    {
        /** @var Video $video */
        $video = Video::where('video_id', $id)->first();
        if (!$video)
            return redirect()->to('/');

        pageData('video_url', $video->video_url);

        return $this->index();
    }

    protected function share()
    {
        pageData('pages', PagesResource::collection(Page::all()));
        pageData('socials', setting()->getArray('socials'));
        pageData('menus', setting()->getArray('menus'));
        pageData('codeBlocks', setting()->getArray('codeBlocks'));
    }

    protected function getSettings(string $key, $default = '[]'): array
    {
        return json_decode(setting($key, $default), true);
    }
}
