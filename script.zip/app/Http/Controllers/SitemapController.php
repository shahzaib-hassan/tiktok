<?php

namespace App\Http\Controllers;

use App\Models\Page;
use Illuminate\Support\Facades\Response;
use function Symfony\Component\String\s;

class SitemapController extends Controller
{
    public function index(): \Illuminate\Http\Response
    {
        $view = view('sitemap', [
            'pages' => Page::all()
        ]);

        return response((string)$view)->withHeaders([
            'Content-Type' => 'application/xml; charset=utf-8'
        ]);
    }
}
