<?php

namespace App\Http\Resources;

use App\Models\Page;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin Page
 */
class PagesResource extends JsonResource
{
    public function toArray($request): array
    {
        return [
            'title' => $this->title,
            'slug' => $this->slug,
            'excerpt' => $this->excerpt,
            'body' => $this->body,
            'created_at' => $this->created_at->getTimestampMs(),
            'updated_at' => optional($this->created_at)->getTimestampMs(),
        ];
    }
}
