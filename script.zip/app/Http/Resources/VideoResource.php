<?php

namespace App\Http\Resources;

use App\Models\Video;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * @mixin Video
 */
class VideoResource extends JsonResource
{
    public static $wrap = null;

    public function toArray($request): array
    {
        return array_merge(parent::toArray($request), [
            'uploaded_at'=> $this->uploaded_at->getTimestampMs()
        ]);
    }
}
