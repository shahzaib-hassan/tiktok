<?php

namespace App\DTO\TikTok;

use Spatie\DataTransferObject\FlexibleDataTransferObject;

class Video extends FlexibleDataTransferObject
{
	/** @var string $id */
	public $id;

	/** @var int $height */
	public $height;

	/** @var int $width */
	public $width;

	/** @var int $duration */
	public $duration;

	/** @var string $ratio */
	public $ratio;

	/** @var string $cover */
	public $cover;

	/** @var string $originCover */
	public $originCover;

	/** @var string $dynamicCover */
	public $dynamicCover;

	/** @var string $playAddr */
	public $playAddr;

	/** @var string $downloadAddr */
	public $downloadAddr;

	/** @var string[] $shareCover */
	public $shareCover;

	/** @var string $reflowCover */
	public $reflowCover;

	/** @var int $bitrate */
	public $bitrate;

	/** @var string $encodedType */
	public $encodedType;

	/** @var string $format */
	public $format;

	/** @var string $videoQuality */
	public $videoQuality;

	/** @var string $encodeUserTag */
	public $encodeUserTag;

	/** @var string $codecType */
	public $codecType;

	/** @var string $definition */
	public $definition;
}
