<?php

namespace App\DTO\TikTok;

use Spatie\DataTransferObject\FlexibleDataTransferObject;

class Stats extends FlexibleDataTransferObject
{
	/** @var int $diggCount */
	public $diggCount;

	/** @var int $shareCount */
	public $shareCount;

	/** @var int $commentCount */
	public $commentCount;

	/** @var int $playCount */
	public $playCount;
}
