<?php

namespace App\DTO\TikTok;

use Spatie\DataTransferObject\FlexibleDataTransferObject;

class AuthorStats extends FlexibleDataTransferObject
{
	/** @var int $followerCount */
	public $followerCount;

	/** @var int $followingCount */
	public $followingCount;

	/** @var int $heart */
	public $heart;

	/** @var int $heartCount */
	public $heartCount;

	/** @var int $videoCount */
	public $videoCount;

	/** @var int $diggCount */
	public $diggCount;
}
