<?php

namespace App\DTO\TikTok;

use Spatie\DataTransferObject\FlexibleDataTransferObject;

class Item extends FlexibleDataTransferObject
{
	/** @var string $id */
	public $id;

	/** @var string $desc */
	public $desc;

	/** @var string $createTime */
	public $createTime;

	/** @var \App\DTO\TikTok\Video $video */
	public $video;

	/** @var string $author */
	public $author;

	/** @var \App\DTO\TikTok\Music $music */
	public $music = null;

	/** @var \App\DTO\TikTok\Stats $stats */
	public $stats;

//	/** @var \App\DTO\TikTok\AuthorStats $authorStats */
//	public $authorStats = null;

	/** @var string $nickname */
	public $nickname;

	/** @var string $authorId */
	public $authorId;

	/** @var string $authorSecId */
	public $authorSecId = null;

	/** @var string $avatarThumb */
	public $avatarThumb;
}
