<?php

namespace App\DTO\TikTok;

use Spatie\DataTransferObject\FlexibleDataTransferObject;

class Music extends FlexibleDataTransferObject
{
	/** @var string $id */
	public $id;

	/** @var string $title */
	public $title;

	/** @var string $playUrl */
	public $playUrl;

	/** @var string $coverLarge */
	public $coverLarge;

	/** @var string $coverMedium */
	public $coverMedium;

	/** @var string $coverThumb */
	public $coverThumb;

	/** @var string $authorName */
	public $authorName;

	/** @var bool $original */
	public $original;

	/** @var int $duration */
	public $duration;

	/** @var string $album */
	public $album;

	/** @var int $scheduleSearchTime */
	public $scheduleSearchTime;
}
