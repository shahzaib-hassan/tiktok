<?php

namespace App\Repository;

use Exception;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class Proxies
{
    public static function get(): array
    {
        return array_values(setting()->getArray('proxies'));
    }

    public static function push(string $proxy)
    {
        $proxies = static::get();
        $proxies[] = $proxy;
        static::update($proxies);
    }

    public static function update(array $proxies)
    {
        setting(['proxies' => json_encode($proxies)])->save();
    }

    public static function remove(string $proxy)
    {
        $proxies = static::get();
        $newProxies = array_diff($proxies, [$proxy]);
        static::update($newProxies);
    }

    public static function hasAny(): bool
    {
        return count(static::get()) > 0;
    }

    public static function getRandom(): string
    {
        return Arr::random(static::get());
    }

    public static function isValidProxy(string $proxy): bool
    {
        try {
            $response = Http::timeout(10)
                ->withOptions(compact('proxy'))
                ->get('http://lumtest.com/myip.json');

            $body = $response->json();

            return $response->ok() && !is_null($body) && Arr::has($body, 'ip');

        } catch (Exception $e) {
            return false;
        }
    }
}
