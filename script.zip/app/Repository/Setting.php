<?php

namespace App\Repository;

use Illuminate\Contracts\Cache\Store;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Filesystem\FilesystemAdapter as Filesystem;
use Illuminate\Support\Arr;

class Setting
{

    /**
     * Cache key for save
     */
    const CACHE_KEY = 'setting:cache';

    /**
     * The settings data.
     *
     * @var array
     */
    protected $data = [];

    /**
     * The settings updated data.
     *
     * @var array
     */
    protected $updatedData = [];

    /**
     * The settings updated data.
     *
     * @var array
     */
    protected $persistedData = [];

    /**
     * Whether the store has changed since it was last loaded.
     *
     * @var boolean
     */
    protected $unsaved = false;

    /**
     * Whether the settings data are loaded.
     *
     * @var boolean
     */
    protected $loaded = false;

    /**
     * Default values.
     *
     * @var array
     */
    protected $defaults = [];

    /**
     * @var Store
     */
    protected $cache = null;

    /**
     * Cache TTL in seconds.
     *
     * @var int
     */
    protected $cacheTtl = 15;

    /**
     * Whether to reset the cache when changing a setting.
     *
     * @var boolean
     */
    protected $cacheForgetOnWrite = true;
    /**
     * @var Filesystem
     */
    protected $files;

    protected $writeable = true;


    /**
     * @param Filesystem $files
     * @param string|null $path
     */
    public function __construct(Filesystem $files, string $path = null)
    {
        $this->files = $files;
        $this->setPath($path ?: '/settings.json');
    }

    /**
     * Set default values.
     *
     * @param array $defaults
     */
    public function setDefaults(array $defaults)
    {
        $this->defaults = $defaults;
    }

    /**
     * Set the cache.
     * @param Store $cache
     * @param int|null $ttl
     * @param bool|null $forgetOnWrite
     */
    public function setCache(Store $cache, int $ttl = null, bool $forgetOnWrite = null)
    {
        $this->cache = $cache;
        if ($ttl !== null) {
            $this->cacheTtl = $ttl;
        }
        if ($forgetOnWrite !== null) {
            $this->cacheForgetOnWrite = $forgetOnWrite;
        }
    }

    /**
     * Get a specific key from the settings data.
     *
     * @param string|array $key
     * @param mixed $default Optional default value.
     *
     * @return mixed
     */
    public function get($key, $default = null)
    {
        if (is_null($default)) {
            $default = Arr::get($this->defaults, $key);
        } elseif (is_array($key) && is_array($default)) {
            $default = array_merge(Arr::only($this->defaults, $key), $default);
        }

        $this->load();

        return is_array($key) ?
            array_merge(Arr::only($this->data, $key), $default) :
            Arr::get($this->data, $key, $default);
    }

    public function getArray(string $key, array $default = []): array
    {
        $value = $this->get($key);
        return is_string($value) ? json_decode($value, true) : $default;
    }

    public function setArray(string $key, array $value): Setting
    {
        return $this->set($key, json_encode($value));
    }

    public function getBoolean(string $key, bool $default = false): bool
    {
        $value = $this->get($key);
        return !is_null($value) ? boolval($value) : $default;
    }

    /**
     * Determine if a key exists in the settings data.
     *
     * @param string $key
     *
     * @return boolean
     */
    public function has(string $key): bool
    {
        $this->load();

        return Arr::has($this->data, $key);
    }

    /**
     * Set a specific key to a value in the settings data.
     *
     * @param string|array $key Key string or associative array of key => value
     * @param mixed $value Optional only if the first argument is an array
     */
    public function set($key, $value = null): self
    {
        $this->load();
        $this->unsaved = true;

        if (is_array($key)) {
            foreach ($key as $k => $v) {
                Arr::set($this->data, $k, $v);
                Arr::set($this->updatedData, $k, $v);
            }
        } else {
            Arr::set($this->data, $key, $value);
            Arr::set($this->updatedData, $key, $value);
        }

        return $this;
    }

    /**
     * Unset a key in the settings data.
     *
     * @param string $key
     */
    public function forget(string $key)
    {
        $this->unsaved = true;

        if ($this->has($key)) {
            Arr::forget($this->data, $key);
            Arr::forget($this->updatedData, $key);
        }
    }

    /**
     * Unset all keys in the settings data.
     *
     * @return void
     */
    public function forgetAll()
    {
        $this->unsaved = true;
        $this->data = array();
        $this->updatedData = array();
    }

    /**
     * Get all settings data.
     *
     * @return array
     */
    public function all(): array
    {
        $this->load();

        return $this->data;
    }

    /**
     * Save any changes done to the settings data.
     *
     * @return void
     */
    public function save()
    {
        if (!$this->unsaved) {
            // either nothing has been changed, or data has not been loaded, so
            // do nothing by returning early
            return;
        }

        if ($this->cache && $this->cacheForgetOnWrite) {
            $this->cache->forget(static::CACHE_KEY);
        }

        $this->write($this->data);
        $this->unsaved = false;
    }

    /**
     * Make sure data is loaded.
     *
     * @param bool $force a reload of data. Default false.
     */
    public function load(bool $force = false)
    {
        if (!$this->loaded || $force) {
            $this->data = $this->readData();
            $this->persistedData = $this->data;
            $this->data = array_merge($this->updatedData, $this->data);
            $this->loaded = true;
        }
    }

    /**
     * Read data from a store or cache
     *
     * @return array
     */
    private function readData(): array
    {
        if ($this->cache) {
            return $this->cache->remember(static::CACHE_KEY, $this->cacheTtl, function () {
                return $this->read();
            });
        }

        return $this->read();
    }

    /**
     * Set the path for the JSON file.
     *
     * @param string $path
     */
    public function setPath(string $path)
    {
        $dirArr = explode(DIRECTORY_SEPARATOR, $path);
        unset($dirArr[count($dirArr) - 1]);
        $dir = implode(DIRECTORY_SEPARATOR, $dirArr);
        $storage_dir = storage_path($dir);

        if (!is_writable($storage_dir)) {
            $this->writeable = false;
        } // If the file does not already exist, we will attempt to create it.
        if (!$this->files->exists($path) && $this->writeable) {
            $result = $this->files->put($path, '{}');
            if ($result === false) {
                throw new \InvalidArgumentException("Could not write to $path.");
            }
        }

        $this->path = $path;
    }

    public function isWriteable(): bool
    {
        return $this->writeable;
    }

    /**
     * {@inheritdoc}
     * @throws FileNotFoundException
     */
    protected function read()
    {
        $contents = $this->files->get($this->path);

        $data = json_decode($contents, true);

        if ($data === null) {
            throw new \RuntimeException("Invalid JSON in {$this->path}");
        }

        return $data;
    }

    /**
     * {@inheritdoc}
     */
    protected function write(array $data)
    {
        if ($data) {
            $contents = json_encode($data);
        } else {
            $contents = '{}';
        }

        $this->files->put($this->path, $contents);
    }
}
