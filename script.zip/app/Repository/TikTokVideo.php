<?php

namespace App\Repository;

use App\DTO\TikTok\Item;
use App\DTO\TikTok\Music;
use App\Models\Video;
use Exception;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class TikTokVideo
{

    const WRAPPER_URL = "https://codespikex.com/tiktok-api/v2";
    const MAX_TRIES = 2;

    /** @var Item */
    protected $item = null;
    /** @var Exception|ConnectionException */
    protected static $exception = null;

    public static function find(string $url): ?TikTokVideo
    {
        
        try {

            if (!filter_var($url, FILTER_SANITIZE_STRING)) {
                throw new \InvalidArgumentException("URL is invalid.");
            }

            $reqCount = 0;

            do {


                $client = Http::timeout(30);
                if (Proxies::hasAny())
                    $client->withOptions(['proxy' => Proxies::getRandom()]);

                $response = $client->get($url);

                $body = $response->body();


                if (!$response->ok() || !str_contains($body, "window['SIGI_STATE']")) {
                    continue;
                }

                preg_match("/\"\d+\":(.+)?\},\"([A-Za-z][^ ])+\"/", $body, $matches);
                if (isset($matches[1]) && is_string($matches[1])) {
                    $page = json_decode($matches[1], true);
                    return new static(new Item($page));
                }

            } while ($reqCount <= self::MAX_TRIES);

        } catch (Exception $exception) {
            static::$exception = $exception;
            return null;
        }

        return null;
    }

    public static function findNwmUrl(string $url): array
    {
        if (!filter_var($url, FILTER_SANITIZE_STRING)) {
            throw new \InvalidArgumentException("URL is invalid.");
        }

        $api_url = self::WRAPPER_URL
            . "?url=" . urlencode($url)
            . "&license=" . env('APP_LICENSE');

        $response = Http::get($api_url);
        $data = $response->json();

        return collect([$data['no_watermark_link'], $data['no_watermark_link_2'], $data['no_watermark_link_3']])
            ->filter()->values()->toArray();
    }

    public static function getException(): ?Exception
    {
        return static::$exception;
    }

    public function __construct(Item $item)
    {
        $this->item = $item;
    }

    public function getBaseItem(): ?Item
    {
        return $this->item;
    }

    public function toModel(): Video
    {
        $item = $this->item;
        $downloadURL = is_string($item->video->downloadAddr) ?
            $item->video->downloadAddr :
            $item->video->playAddr;

        return new Video([
            'title' => $item->desc,
            'video_id' => $item->id,
            'caption' => $item->desc,
            'uploaded_at' => Carbon::createFromTimestampUTC((int)$item->createTime),
            'url' => $downloadURL,
            'url_nwm' => null,
            'cover' => $item->video->cover,
            'music' => $item->music instanceof Music ? [
                'id' => $item->music->id,
                'title' => $item->music->title,
                'cover' => $item->music->coverMedium,
                'author' => $item->music->authorName,
                'url' => $item->music->playUrl
            ] : null,
            'user' => [
                'name' => $item->nickname,
                'username' => $item->author,
                'cover' => $item->avatarThumb
            ],
            'stats' => [
                'comments' => $item->stats->commentCount,
                'likes' => $item->stats->diggCount,
                'share' => $item->stats->shareCount,
                'play' => $item->stats->playCount,
            ],
        ]);
    }
}
