<?php

namespace App\Repository;

class Meta
{
    /** @var array */
    protected $attributes = [];

    /** @return self|string */
    public function title(string $title = null)
    {
        return $this->setOrGet('title', $title, function () {
            return config('app.name');
        });
    }

    /** @return self|string */
    public function description(string $description = null)
    {
        return $this->setOrGet('description', $description, function () {
            return config('app.desc');
        });
    }

    /** @return self|string */
    public function keywords(string $keywords = null)
    {
        return $this->setOrGet('keywords', $keywords, function () {
            return config('app.keywords');
        });
    }

    /** @return self|string */
    public function cover(string $cover = null)
    {
        return $this->setOrGet('cover', $cover, 'imgs/cover.jpg');
    }

    /** @return self|string */
    public function url(string $url = null)
    {
        return $this->setOrGet('url', $url, function () {
            return config('app.url');
        });
    }

    protected function setOrGet(string $key, string $value = null, $default = null)
    {
        if (!is_null($value)) {
            $this->attributes[$key] = $value;
            return $this;
        }

        return $this->getAttribute($key, $default);
    }

    public function getAttribute(string $key, $default = null)
    {
        if (isset($this->attributes[$key])) {
            return $this->attributes[$key];
        }
        return value($default);
    }
}
