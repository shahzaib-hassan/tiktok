<?php

namespace App\Repository;

use Illuminate\Contracts\Support\Arrayable;
use JsonSerializable;

class PageData
{
    protected $data = [];

    public function share($key, $value = null): self
    {
        if (is_array($key)) {
            $this->data = array_merge_recursive($this->data, $key);
        }
        if (!is_null($value) && is_string($key)) {
            if ($value instanceof Arrayable || $value instanceof JsonSerializable)
                $value = $value->toArray(request());

            data_set($this->data, $key, $value);
        }

        return $this;
    }

    public function __toString(): string
    {
        if (count(array_keys($this->data)) < 1)
            return '{}';
        return json_encode($this->data);
    }
}
