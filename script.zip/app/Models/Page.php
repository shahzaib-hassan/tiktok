<?php

namespace App\Models;

/**
 * @property string $title
 * @property string $slug
 * @property string $excerpt
 * @property string $body
 */
class Page extends Model
{
    protected $fillable = [
        'title', 'slug', 'excerpt', 'body'
    ];

    protected $hidden = [
        'created_at', 'updated_at'
    ];

    protected $casts = [
      'created_at'=> 'datetime',
      'updated_at'=> 'datetime',
    ];
}
