<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

/**
 * @property string $title
 * @property string $video_id
 * @property string $caption
 * @property string $cover
 * @property string $url
 * @property string $url_nwm
 * @property array $music
 * @property array $user
 * @property array stats
 * @property Carbon $uploaded_at
 * @property int dl_count
 * @property string $video_url
 * @property string $share_url
 * @method static Builder trending()
 * @method static Builder recent()
 */
class Video extends Model
{
    protected $fillable = [
        'title', 'video_id', 'caption', 'cover', 'url', 'url_nwm', 'music',
        'user', 'stats', 'uploaded_at', 'dl_count'
    ];

    protected $casts = [
        'music' => 'array',
        'user' => 'array',
        'stats' => 'array',
        'dl_count' => 'int',
        'update_at' => 'datetime',
        'created_at' => 'datetime',
        'uploaded_at' => 'datetime'
    ];

    protected $hidden = ['id', 'created_at', 'updated_at'];

    protected $appends = ['video_url', 'share_url'];

    public function getVideoUrlAttribute(): string
    {
        $user = $this->user;
        if (is_string($user))
            $user = json_decode($user, true);
        $username = data_get($user, 'username');
        return "https://www.tiktok.com/@{$username}/video/{$this->video_id}";
    }

    public function getShareUrlAttribute(): string
    {
        return rtrim(config('app.url'), '/') . '/video/' . $this->video_id;
    }

    public function scopeTrending(Builder $query): Builder
    {
        return $query->orderByDesc('dl_count');
    }

    public function scopeRecent(Builder $query): Builder
    {
        return $query->orderByDesc('id');
    }
}
