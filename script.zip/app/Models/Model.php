<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model as BaseModel;

/**
 * @property int $id
 * @property Carbon $created_at
 * @property Carbon $updated_at
 * @method static self updateOrCreate(array $attribute, array $values = [])
 * @method static Builder where(string $column, $values)
 */
abstract class Model extends BaseModel
{

}
