<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Laravel\Lumen\Auth\Authorizable;
use Tymon\JWTAuth\Contracts\JWTSubject;

/**
 * @property string $fname
 * @property string $lname
 * @property string $full_name
 * @property string $email
 * @property string $password
 * @property string $role
 * @property string $isAdmin
 */
class User extends Model implements AuthenticatableContract, AuthorizableContract, JWTSubject
{
    use Authenticatable, Authorizable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email', 'fname', 'lname', 'role', 'password'
    ];

    protected $visible = [
        'fname', 'lname', 'email',
        'role', 'full_name', 'isAdmin'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    protected $appends = ['full_name', 'isAdmin'];

    public function getFullNameAttribute(): string
    {
        return $this->fname . ' ' . $this->lname;
    }

    public function getIsAdminAttribute(): bool
    {
        return $this->role == 'admin';
    }

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims(): array
    {
        return [
            'fname' => $this->fname,
            'lname' => $this->lname,
            'full_name' => $this->full_name,
            'email' => $this->email
        ];
    }
}
