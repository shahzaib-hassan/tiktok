<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //.
    }

    public function boot()
    {
        $this->setDefaults();

        if ($this->app->runningInConsole()) return;

        $app = setting()->getArray('site');

        pageData('app', [
            'name' => data_get($app, 'name'),
            'desc' => data_get($app, 'desc'),
            'keywords' => data_get($app, 'keywords'),
            'version' => config('app.version'),
            'api_version'=> data_get($app, 'api_version')
        ]);
    }

    protected function setDefaults()
    {
        setting()->setDefaults([
            'site' => json_encode([
                'name' => config('app.name'),
                'desc' => config('app.desc'),
                'keywords' => config('app.keywords'),
                'api_version'=> config('app.api_version')
            ]),
            'menus' => '[]',
            'proxies' => '[]',
            'socials' => '[]',
            'codeBlocks' => json_encode([
                'headerCodeBlock' => '',
                'ads' => []
            ])
        ]);
    }
}
