<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Installer - {{config('app.name')}}</title>

    <link rel="stylesheet" href="/css/theme/light.css">

    @include("install.style")
</head>
<body>
<main>
    <div class="logo">
        <img src="/imgs/logos/logo-wide.png" alt="TikTokInstaller">
    </div>

    @include("install.step-welcome")
    @include("install.step-agreement")
    @include("install.step-requirements")
    @include("install.step-install")
    @include("install.step-success")

    @include("install.script")
</main>
</body>
</html>
