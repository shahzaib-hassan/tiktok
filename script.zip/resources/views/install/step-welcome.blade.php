<section id="welcome" class="center show">
    <h1>{{config('app.name')}} Installation</h1>
    <p>Welcome! {{config('app.name')}} is an online web scraper which allows you to scrape TikTok video links to download
        Videos without watermark</p>
    <p class="mb-40"><b>Installation process is very easy and it takes less than 2 minutes!</b></p>
    <button>
        Start Installation
    </button>
</section>
