@include("install.script-core")

<script>

    const Lite = {};

    Lite.UpgradeWizard = class UpgradeWizard {

        steps = {
            1: '#welcome',
            2: '#requirements',
            3: '#install',
            4: '#success'
        }
        current_step = 1;

        constructor() {
            this.stepOne()
        }

        stepOne() {
            let next = $(`${this.steps[1]} button`);
            next.bind('click', () => {
                this.transite(2, [
                    () => {
                        $('.logo').classList.add('min')
                    },
                    this.stepTwo.bind(this)
                ]);
            })
        }

        stepTwo() {
            let next = $(`${this.steps[2]} button`);
            if (!next.disabled)
                next.bind('click', () => {
                    this.transite(3, this.stepThree.bind(this))
                })
        }

        stepThree() {
            let finish = $(`${this.steps[3]} form`)

            finish.bind('submit', this.install.bind(this))

            document.upgrade.db_driver?.addEventListener('change', (e) => {
                const target = e.target
                document.upgrade.db_port.value = target.value === 'pgsql' ? 5432 : 3306
            })
        }


        async install(e) {
            e.preventDefault();

            /**
             * @type {HTMLFormElement} form
             */
            const form = document.upgrade;

            const formData = {
                app: {
                    url: form.app_url.value,
                },
                db: {
                    driver: form.db_driver.value,
                    host: form.db_host.value,
                    port: Number(form.db_port.value),
                    database: form.db_name.value,
                    username: form.db_username.value,
                    password: form.db_password.value,
                    prefix: form.db_tablePrefix.value
                },
                user: {
                    email: form.email.value,
                    password: form.user_password.value
                },
                license: form.license.value
            }


            try {
                this.loading(true)

                const res = await post("/api/upgrade", formData)
                if (res.status !== 200)
                    throw new Error(res.data.message)

                this.error('', false)

                this.transite(4, () => {
                    $('.logo').classList.remove('min')
                });

            } catch (e) {
                this.error(e.message)
            } finally {
                this.loading(false)
            }
        }


        loading(show = true) {
            let body = $('body')
            if (!body) return
            if (show)
                body.classList.add('on-progress')
            else body.classList.remove('on-progress')
        }

        error(error, show = true) {
            let errorText = $(`${this.steps[3]} .form-errors`)

            if (errorText) {

                if (!show) {
                    errorText.classList.remove('show')
                    errorText.innerText = ''
                    return
                }

                errorText.classList.add('show')
                if (typeof error === 'object') {
                    error.innerText = ''
                    Object.values(error).forEach(value => {
                        error.innerText += value + "<br/>"
                    })
                } else
                    errorText.innerText = error
                window.scrollTo(0, 0)
            }

        }


        /**
         * Transite
         * @param {number} to
         * @param {*} callback
         */
        transite(to, callback = null) {
            transition(`${this.steps[this.current_step]}`,
                `${this.steps[to]}`, callback);
            this.current_step = to;
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        //Start Installer
        new Lite.UpgradeWizard();
    })
</script>
