import Vue     from "vue"
import VueMeta from "vue-meta"
// Ripple Directive
import Ripple  from "vue-ripple-directive"

import App                   from "~/Layouts/App.vue"
import router                from "~/routes"
import store                 from "~/store"
// Cookie for storing user token
import cookies               from "js-cookie"
// Components
import Components            from "~/Components"
// Filters
import Filters               from "~/filters"
import {Page}                from "~/store/modules/pages"
import {isElement, isString} from "lodash-es"
import {Meta}                from "~/store/modules/app"
import {Ad, Menu, Social}    from "~/store/modules/settings"

Vue.use(VueMeta, {
    refreshOnceOnNavigation: true
})
Vue.use(Components)
Vue.use(Filters)
//Ripple
Ripple.color = "var(--ripple-effect)"
Vue.directive("ripple", Ripple)

const root: HTMLElement = document.querySelector("#app")

async function mount() {
    const token: string = cookies.get("token")
    if (isString(token)) {
        await store.dispatch("auth/loginWithToken", token)
    }

    new Vue({
        store,
        router,
        beforeCreate,
        render: h => h(App)
    }).$mount(root)
}


//Before Creating
async function beforeCreate() {

    const page = JSON.parse(root.dataset.page) as {
        pages: Page[]
        app: Meta,
        socials: Social[],
        menus: Menu[],
        codeBlocks: {
            ads: Ad[],
            headerCodeBlock: string
        },
        video_url: string
    }

    await store.dispatch("app/updateConfig", page.app)
    await store.dispatch("pages/setPages", page.pages)
    await store.dispatch("settings/updateSocials", page.socials)
    await store.dispatch("settings/updateMenus", page.menus)
    if (page.codeBlocks?.ads)
        await store.dispatch("settings/updateAds", page.codeBlocks.ads)
    if (page.codeBlocks?.headerCodeBlock)
        await store.dispatch("settings/updateHeaderCodeBlock", page.codeBlocks.headerCodeBlock)

    if(isString(page.video_url)) {
        await store.dispatch("video/search", page.video_url)
    }

    hidePreloader()
}

function hidePreloader() {

    const preloader: HTMLElement = document.querySelector("#preloader")
    if (!isElement(preloader)) {
        return
    }

    const anim = preloader?.animate([
        {opacity: "1"},
        {opacity: "0"}
    ], {
        duration: 500,
        iterations: 1,
        fill: "forwards"
    })

    anim.addEventListener("finish", () => {
        preloader?.remove()
        document.querySelector<HTMLStyleElement>("style#preloader-css")
            ?.remove()
    })

    anim.play()
}

mount()
