import Vue                      from "vue"
import VueRouter, {RouteConfig} from "vue-router"
import guard                    from "vue-router-multiguard"
import {guest, auth}            from "./middleware"
import NProgress                from "nprogress"

//Fixing Duplication Error
const pushFn = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
    return pushFn.call(this, location).catch(err => err)
}

const ADMIN_PREFIX = "admin"

//Using Vue Router
Vue.use(VueRouter)

//Landing Page
import HomeLayout           from "~/Layouts/HomeLayout.vue"
import Home                 from "~/Pages/Home.vue"
import {windowSmoothScroll} from "~/utils/helpers"

const routes: Array<RouteConfig> = [
    {
        path: "/",
        component: HomeLayout,
        children: [
            {
                path: "",
                name: "home",
                meta: {layout: "default"},
                component: Home
            },
            {
                path: "video/:id",
                name: "video",
                meta: {layout: "default"},
                component: Home
            }
        ]
    },
    {
        path: "/page/:slug",
        name: "page",
        meta: {layout: "default"},
        component: () => import(/* webpackChunkName: "page" */  "~/Pages/Page.vue")
    },
    //404 Page
    {
        path: "/404",
        name: "Page404",
        meta: {layout: "default"},
        component: () => import(/* webpackChunkName: "error.404" */  "~/Pages/Page404.vue")
    },
    //Redirect to Log in
    {
        path: `/${ADMIN_PREFIX}`,
        name: "admin",
        redirect: `/${ADMIN_PREFIX}/login`,
        component: () => import(/* webpackChunkName: "admin.layout" */  "~/Layouts/AdminLayout.vue"),
        children: [
            {
                path: `dashboard`,
                name: "admin.dashboard",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.dashboard" */  "~/Pages/Admin/Dashboard.vue")
            },
            {
                path: `settings`,
                name: "admin.settings",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.settings" */  "~/Pages/Admin/Settings.vue")
            },
            {
                path: `proxies`,
                name: "admin.proxies",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.proxies_list" */  "~/Pages/Admin/Proxies/Index.vue")
            },
            {
                path: `code-blocks`,
                name: "admin.code",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.code_blocks" */  "~/Pages/Admin/CodeBlocks.vue")
            },
            {
                path: `pages`,
                name: "admin.pages.list",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.pages_list" */  "~/Pages/Admin/Pages/List.vue")
            },
            {
                path: `pages/:action/:slug?`,
                name: "admin.pages.modify",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.pages_create" */  "~/Pages/Admin/Pages/Create.vue")
            },
            {
                path: `menu`,
                name: "admin.menu",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.menu" */  "~/Pages/Admin/Menu.vue")
            },
            {
                path: `account`,
                name: "admin.account",
                meta: {layout: "default", group: "admin"},
                beforeEnter: guard([auth]),
                component: () => import(/* webpackChunkName: "admin.account" */  "~/Pages/Admin/Account.vue")
            }
        ]
    },
    //Login Route
    {
        path: `/${ADMIN_PREFIX}/login`,
        name: "admin.login",
        meta: {layout: "auth"},
        beforeEnter: guard([guest]),
        component: () => import(/* webpackChunkName: "admin.login" */  "~/Pages/Auth/Login.vue")
    },
    //Admin Routes
    {
        path: "/*",
        redirect: {name: "Page404"}
    }
]

const router = new VueRouter({
    mode: "history",
    base: process.env.BASE_URL,
    routes
})

router.beforeEach((to, from, next) => {
    windowSmoothScroll()
    next()
})

router.beforeResolve((to, from, next) => {
    // If this isn't an initial page load.
    if (to.name) {
        // Start the route progress bar.
        NProgress.start()
    }
    next()
})

router.afterEach(() => {
    // Complete the animation of the route progress bar.
    NProgress.done()
})


export default router
