import {NavigationGuard} from "vue-router"
import router            from "~/routes"
import store             from "~/store"

const Logout: NavigationGuard = async function () {
    await store.dispatch("auth/logout")
    return router.push({name: "home"})
}

export default Logout
