import {NavigationGuard} from "vue-router"
import cookies           from "js-cookie"
import router            from "~/routes"

const Guest: NavigationGuard = function (to, from, next) {
    const token = cookies.get("token") as string
    if (!token)
        return next()
    return router.push({name: "admin.dashboard"})
}

export default Guest
