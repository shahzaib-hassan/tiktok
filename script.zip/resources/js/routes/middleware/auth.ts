import {NavigationGuard} from "vue-router"
import router            from "~/routes"
import cookies           from "js-cookie"

const Auth: NavigationGuard = function (to, from, next) {
    const token = cookies.get("token") as string
    if (token)
        return next()
    return router.push({name: "home"})
}

export default Auth
