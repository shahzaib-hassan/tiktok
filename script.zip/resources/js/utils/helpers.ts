export function windowSmoothScroll() {
	let currentScroll = document.documentElement.scrollTop || document.body.scrollTop
	if (currentScroll > 0) {
		window.requestAnimationFrame(windowSmoothScroll)
		window.scrollTo(0, Math.floor(currentScroll - (currentScroll / 5)))
	}
}

/**
 * Detect any html tag
 * @param text
 * @return boolean
 */
export function sanitize(text: string): boolean {
	return /((<\/?[^]+>)+)/g.test(text)
}

/**
 * Detect any html comment
 * @param text
 * @return boolean
 */
export function sanitizeComment(text: string): boolean {
	return /((<![^]+>)+)/g.test(text)
}

export function arrayMove<T>(arr: Array<T>, oldIndex: number, newIndex: number): Array<T> {
	while (oldIndex < 0) {
		oldIndex += arr.length;
	}
	while (newIndex < 0) {
		newIndex += arr.length;
	}
	if (newIndex >= arr.length) {
		let k = newIndex - arr.length;
		while ((k--) + 1) {
			arr.push(undefined);
		}
	}
	arr.splice(newIndex, 0, arr.splice(oldIndex, 1)[0]);
	return arr;
}