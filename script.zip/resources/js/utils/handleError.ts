import {AxiosError} from "axios"
import {toast}      from "~/utils/toast"
import {notify}     from "~/utils/notification"

export function handleError(error: AxiosError<{ message: string }>, useNotify = false) {
    if (error.response?.status === 422) {

        const errors = Object.values(error.response.data).flat()

        for (const err of errors)
            toast(err, "error")

        return
    }

    const msg = error?.response?.data?.message || "Something went wrong."
    useNotify ? notify(msg) : toast(msg, "error")
}
