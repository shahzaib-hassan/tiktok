import cookies from "js-cookie"

export function getAxiosAuth() {
    return {
        headers: {
            "Authorization": `Bearer ${cookies.get("token")}`
        }
    }
}
