import Vue from "vue"

let index = 1

export function notify(message: string) {
    Vue.set($NOTIFICATION, "msg", {message, index})
    index++
}

export const $NOTIFICATION = Vue.observable({
    msg: {message: null, index: 0}
})
