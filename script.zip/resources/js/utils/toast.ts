import Vue from "vue"

export type ToastType = "success" | "error" | "info" | "warning" | string
let index = 0


export function toast(message: string, type: ToastType = "success") {
    $TOASTS.items = {...$TOASTS.items, [index]: {message, type}}
    index++
}

export const $TOASTS = Vue.observable({
    items: {} as Record<string, Toast>
})

export type Toast = {
    message: string
    type: ToastType
}
