<template>
    <component :is="layout">
    </component>
</template>
<script lang="ts">
import DefaultLayout from "./DefaultLayout.vue"
import AuthLayout    from "./AuthLayout.vue"
import {mapGetters}  from "vuex"

export default {
    components: {
        "default": DefaultLayout,
        "auth": AuthLayout
    },
    metaInfo() {
        return {
            title: 'Home',
            titleTemplate: `%s - ${this.meta.name}`
        }
    },
    computed: {
        ...mapGetters({
            "meta": "app/config"
        }),
        layout() {
            //set layout to simple if layout is not specified
            return this.$route.meta.layout || "default"
        },
        layoutClass() {
            return this.$route.meta.layoutClass || "default-layout"
        }
    }
}
</script>
