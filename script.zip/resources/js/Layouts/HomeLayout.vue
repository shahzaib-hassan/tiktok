<template>
    <div class="container">
        <div class="hero section-bg-dark">
            <section class="fluid">
                <h1>
                    Download <b>TikTok</b> Videos by Url
                </h1>
                <h2>
                    TikTok video Downloader is a fast and free way to download and save TikTok videos as MP4's.
                    Start by putting the TikTok video URL in the box below and click Go.
                </h2>
                <Search/>

                <p>
                    By using this service you agree to our
                    <RouterLink
                        :to="{name:'page',params:{slug: 'terms-of-services'}}"
                    >
                        terms.
                    </RouterLink>
                </p>

                <AdSpace v-if="shouldShowAd" type="below-search"/>
            </section>
        </div>
        <Transition enter-active-class="animated fadeIn" leave-active-class="animated fadeOut" mode="out-in">
            <RouterView/>
        </Transition>
    </div>
</template>

<script lang="ts">
import AdSpace from "Components/Element/AdSpace.vue"
import Search  from "Components/Form/Search.vue"
import ShowAd  from "~/mixins/ShowAd"

export default {
    name: "HomeLayout",
    components: {Search, AdSpace},
    mixins: [ShowAd]
}
</script>
