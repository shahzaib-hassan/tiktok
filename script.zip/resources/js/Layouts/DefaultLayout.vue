<template>
    <div class="application">
        <GreetingBar/>
        <main
            class="default-layout"
        >
            <Header v-model="drawerIsOpen"/>
            <Drawer v-model="drawerIsOpen"/>
            <TransitionGroup
                enter-active-class="animated d-3 fadeIn"
                leave-active-class="animated d-3 FadeOut"
                class="router-view"
            >
                <RouterView
                    :key="$route.meta.group || $route.path"
                ></RouterView>
            </TransitionGroup>
            <AdSpace
                v-if="!hideAds && shouldShowAd"
                type="banner"
                class="space-below"
            />

            <Footer/>
            <VideoBox/>
        </main>
        <Toast/>
        <Notification/>
        <BackToTop/>
    </div>
</template>
<script lang="ts">

import GreetingBar  from "~/Components/Layout/GreetingBar.vue"
import Header       from "~/Components/Layout/Header.vue"
import Drawer       from "~/Components/Layout/Drawer.vue"
import AdSpace      from "~/Components/Element/AdSpace.vue"
import Footer       from "~/Components/Layout/Footer.vue"
import Toast        from "~/Components/Element/Toast.vue"
import BackToTop    from "~/Components/Element/BackToTop.vue"
import VideoBox     from "~/Components/Layout/VideoBox.vue"
import Notification from "~/Components/Element/Notification.vue"
import ShowAd       from "~/mixins/ShowAd"

export default {
    components: {Notification, VideoBox, BackToTop, Toast, Footer, AdSpace, Drawer, Header, GreetingBar},
    mixins: [ShowAd],
    data: () => ({
        drawerIsOpen: false,
        scrollTop: null
    }),
    computed: {
        hideAds() {
            if (this.$route.name === "Page404") return true
            if (!this.$route.meta.group)
                return false
            return this.$route.meta.group === "admin"
        }
    }
}
</script>
