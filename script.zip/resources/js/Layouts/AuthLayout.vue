<template>
    <main class="empty-centered">
        <RouterView/>
        <Toast/>
    </main>
</template>

<script lang="ts">
import Toast from "Components/Element/Toast.vue"

export default {
    name: "AuthLayout",
    components: {Toast}
}
</script>
