<template>
    <div
        class="drawer"
        :class="{'show': open}"
    >
        <Transition name="drawer-overlay" appear>
            <span class="overlay" @click="close" v-show="open"></span>
        </Transition>
        <Transition name="drawer" appear>
            <aside v-show="open">
                <button
                    aria-label="Close Drawer"
                    class="style-none close-btn"
                    @click="close"
                >
                    <span></span>
                    <span></span>
                </button>
                <div class="content">
                    <div class="logo">
                        <img src="/imgs/logos/logo.png" :alt="app.name">
                    </div>
                    <h3 class="title">Pages</h3>
                    <div class="pages">
                        <template v-for="(menu, index) in menus">
                            <RouterLink
                                v-if="!menu.external"
                                v-ripple
                                :key="index"
                                :to="{name:'page',params:{slug:menu.link}}"
                                :data-label="menu.text"
                                active-class="active"
                            >
                                {{ menu.text }}
                            </RouterLink>
                            <a
                                v-else
                                :href="menu.link"
                                :key="index"
                                target="_blank"
                            >{{ menu.text }}</a>
                        </template>
                    </div>
                </div>
                <div class="version" v-if="app.version">
                    <p>Version {{ app.version }}</p>
                </div>
            </aside>
        </Transition>
    </div>
</template>

<script lang="ts">

import {Meta} from "~/store/modules/app"
import {Menu} from "~/store/modules/settings"

export default {
    name: "drawer",
    props: {
        value: Boolean
    },
    data: () => ({
        open: false
    }),
    watch: {
        "value": {
            immediate: true,
            handler(value) {
                this.open = value
            }
        }
    },
    computed: {
        app(): Meta {
            return this.$store.getters["app/config"]
        },
        menus(): Menu[] {
            return this.$store.getters["settings/menus"]
        }
    },
    methods: {
        close() {
            this.open = false
            this.$emit("input", this.open)
        }
    }
}
</script>
