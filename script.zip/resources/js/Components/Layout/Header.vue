<template>
    <header>
        <nav>
            <div class="logo">
                <button
                    aria-label="Open Drawer"
                    class="style-none"
                    @click="openDrawer"
                >
                    <i class="fas fa-bars"></i>
                </button>
                <img
                    @click="goToHome"
                    :alt="app.name"
                    src="/imgs/logos/logo-wide.png"
                    class="can-hover pointer"
                >
            </div>
            <div class="mobile-logo">
                <img
                    @click="goToHome"
                    :alt="app.name"
                    class="can-hover pointer"
                    src="/imgs/logos/logo.png"
                >
            </div>
            <transition
                enter-active-class="animated d-2 zoomIn"
                leave-active-class="animated d-2 zoomOut"
                appear
                mode="out-in"
            >
                <div class="nav" v-if="isLanding">
                    <a
                        v-if="support"
                        :href="support.link || null"
                        class="nav-support"
                    >
                        <span>Support</span> <i class="fas fa-envelope-open-text"></i>
                    </a>
                </div>
                <div class="search" v-if="!isLanding">
                    <button
                        @click="searchFocus = !searchFocus"
                        aria-label="Open Search Input"
                        class="style-none transition"
                    >
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </transition>
        </nav>
        <HeaderSearch v-if="!isLanding" v-model="searchFocus"/>
    </header>
</template>
<script lang="ts">
import HeaderSearch from "Components/Form/HeaderSearch.vue"
import {Meta}       from "~/store/modules/app"
import {Social}     from "~/store/modules/settings"

export default {
    components: {HeaderSearch},
    props: ["value"],
    data: () => ({
        searchFocus: false,
        showDrawer: false
    }),
    watch: {
        "value": {
            immediate: true,
            handler(value) {
                this.showDrawer = value
            }
        }
    },
    computed: {
        app(): Meta {
            return this.$store.getters["app/config"]
        },
        /**
         *
         * @return {boolean}
         */
        isLanding() {
            return this.$route.fullPath === "/"
        },
        support(): Social {
            let socials = this.$store.getters["settings/socials"] as Social[]
            if (!socials || !socials?.length)
                return null
            let mail = null
            socials.forEach((social) => {
                if (social.text === "mail")
                    mail = social
            })
            return mail
        }
    },
    methods: {
        goToHome() {
            this.$router.push({name: "home"})
        },
        openDrawer() {
            this.showDrawer = true
            this.$emit("input", this.showDrawer)
        }
    }
}
</script>
