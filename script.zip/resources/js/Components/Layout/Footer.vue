<template>
    <footer>
        <div class="wrapper">
            <div class="actions">
                <div class="social-links">
                    <a
                        v-for="(social, index) in socials"
                        :key="index"
                        :href="social.link"
                        :aria-label="social.text"
                        target="_blank"
                    >
                        <i
                            :class="[social.text === 'mail' ? 'fas':'fab', social.text === 'mail' ? 'fa-envelope-open-text' : `fa-${social.text}`]"
                        ></i>
                    </a>
                </div>
            </div>
            <div class="nav">
                <RouterLink
                    v-for="(link,label) in pages"
                    :key="link"
                    :to="{name: 'page',params: {slug: link}}"
                >
                    {{ label }}
                </RouterLink>
                <span>
                    © {{ new Date().getFullYear() }} {{ app.name }}
                </span>
            </div>
        </div>
    </footer>
</template>

<script lang="ts">

import {Meta}   from "~/store/modules/app"
import {Social} from "~/store/modules/settings"

export default {
    name: "Footer",
    data: () => ({
        pages: {
            "Terms of Services": "terms-of-services",
            "Privacy Policy": "privacy-policy"
        }
    }),
    computed: {
        app(): Meta {
            return this.$store.getters["app/config"]
        },
        socials(): Social[] {
            return this.$store.getters["settings/socials"]
        }
    }
}
</script>
