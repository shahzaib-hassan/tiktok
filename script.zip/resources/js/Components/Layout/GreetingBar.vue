<template>
    <div class="greeting-bar" v-if="auth">
        <div class="greeting">
            Welcome Back <b>{{ auth.full_name }}</b>
        </div>
        <div class="time">
            {{ time || '00-00-00 AM' }}
        </div>
        <div class="quote">
            {{ quote.quote }} <b>{{ quote.by }}</b>
        </div>
        <div class="actions">
            <router-link :to="{name: 'admin'}">Dashboard</router-link>
            <button class="style-none" @click="logoutUser">Logout</button>
        </div>
    </div>
</template>

<script lang="ts">
import {mapActions} from "vuex"
import {DateTime}   from "luxon"
import quotes       from "~/consts/quotes"
import {sample}     from "lodash-es"
import {User}       from "~/store/modules/auth"

export default {
    name: "GreetingBar",
    data: () => ({
        time: ""
    }),
    mounted() {
        setInterval(this.updateTime, 1000)
    },
    computed: {
        quote() {
            return sample(quotes)
        },
        auth(): User {
            return this.$store.getters["auth/user"]
        }
    },
    methods: {
        ...mapActions({
            "logout": "auth/logout"
        }),
        updateTime() {
            this.time = DateTime.now().toFormat("h:mm:ss a")
        },
        async logoutUser() {
            await this.logout()
            await this.$router.push({name: "home"})
        }
    }
}
</script>
