<template>
    <div class="video-box__container">
        <Transition name="fade">
            <Loader v-if="loading"/>
        </Transition>

        <Transition
            enter-active-class="animated d-3 fadeIn"
            leave-active-class="animated d-3 FadeOut"
            mode="out-in"
            appear
        >
            <div class="video-box" v-if="video">
                <div
                    @keydown.esc="close"
                    class="wrapper"
                    autofocus
                    tabindex="15"
                >
                    <div class="video-player-container">
                        <div
                            class="video-player"
                            :style="{backgroundImage: `url(${video.cover})`}"
                        >
                            <div class="blur"></div>
                            <img :src="video.cover" :alt="video.caption" class="poster">
                        </div>
                        <button
                            @click="close"
                            aria-label="Close Video Box"
                            class="style-none close-btn"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <aside>
                        <div class="user-profile">
                            <div class="avatar">
                                <img :src="video.user.cover" :alt="video.user.name">
                            </div>
                            <div class="details">
                                <h3>{{ video.user.username }}</h3>
                                <h4>{{ video.user.name }} <span>.</span> {{ video.uploaded_at | diffForHuman }}</h4>
                            </div>
                            <a
                                :href="`https://www.tiktok.com/@${video.user.username}`"
                                v-ripple
                                aria-label="More Info"
                                class="style-none more-link"
                                target="_blank"
                            >
                                More <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                        <div class="text" v-if="video.caption" :inner-html.prop="video.caption | linkiefied">
                        </div>
                        <div class="music" v-if="video.music">
                            <i class="fas fa-music"></i>
                            <b>{{ video.music.title }} - {{ video.music.author }}</b>
                            <button
                                v-if="video.music.url"
                                @click.prevent="downloadMusic"
                                v-ripple
                                aria-label="Download Music"
                            >
                                <i class="fas fa-download"></i>
                                Music
                            </button>
                        </div>
                        <div class="states">
                            <div class="states-count" v-if="video.stats">
                                <div class="likes" v-if="video.stats.likes">
                                    <i class="far fa-heart"></i>
                                    {{ video.stats.likes | balance }}
                                </div>
                                <div class="comments" v-if="video.stats.comments">
                                    <i class="far fa-comment-dots"></i>
                                    {{ video.stats.comments | balance }}
                                </div>
                                <div class="shares" v-if="video.stats.play">
                                    <i class="far fa-eye"></i>
                                    {{ video.stats.play | balance }}
                                </div>
                            </div>
                            <div class="share-actions">
                                <template v-if="shareAPI">
                                    <button
                                        @click="share"
                                        aria-label="Share Video Link"
                                        class="style-none share-action share-link"
                                        v-ripple
                                    >
                                        <i class="fas fa-share-alt"></i>
                                    </button>
                                </template>
                                <template v-else>
                                    <a
                                        :href="`https://www.facebook.com/sharer.php?u=${video.share_url}`"
                                        aria-label="Share on Facebook"
                                        class="share-action facebook"
                                        target="_blank"
                                        v-ripple
                                    >
                                        <i class="fab fa-facebook"></i>
                                    </a>
                                    <a
                                        :href="`https://twitter.com/intent/tweet?url=${video.share_url}`"
                                        aria-label="Share on Twitter"
                                        class="share-action twitter"
                                        target="_blank"
                                        v-ripple
                                    >
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a
                                        :href="`whatsapp://send?text=${video.share_url}`"
                                        aria-label="Share on Whatsapp"
                                        class="share-action whatsapp"
                                        target="_blank"
                                        v-ripple
                                    >
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </template>
                                <button
                                    @click="shareShow = !shareShow"
                                    aria-label="Copy Video Link"
                                    class="style-none share-action copy-link"
                                    v-ripple
                                >
                                    <i class="fas fa-link"></i>
                                </button>
                            </div>
                        </div>
                        <Transition
                            enter-active-class="animated fadeIn d-3"
                            leave-active-class="animated fadeOut d-3"
                            appear
                        >
                            <div class="share-url" v-if="shareShow">
                                <input
                                    ref="copy_input"
                                    class="video-url-input"
                                    aria-label="Video URL"
                                    type="text"
                                    readonly
                                    :value="video.share_url"
                                >
                                <i class="fas fa-link prepend"></i>

                                <button @click="copy" class="style-none">
                                    <i class="fas" :class="`fa-${copyIcon}`"></i>
                                </button>
                            </div>
                        </Transition>

                        <AdSpace type="square"/>
                        <Transition
                            enter-active-class="animated d-3 fadeIn"
                            leave-active-class="animated d-3 FadeOut"
                            mode="out-in"
                        >
                            <button
                                v-if="!fetched"
                                :disabled="fetching"
                                :class="{'fetching':fetching}"
                                @click="fetch"
                                aria-label="Fetch Download Links"
                                class="style-none button fetch-button mt-auto"
                                v-ripple
                            >
                                <i class="fas fa-fan"></i>
                                <span>Fetch Download Links</span>
                            </button>

                            <div v-else class="button-group">
                                <a
                                    :data-disabled="!video.url"
                                    :href="`/download?url=${encodeURIComponent(video.url)}&type=video&fileName=${encodeURIComponent(getFileTitle())}`"
                                    aria-label="Download Original Video"
                                    target="_blank"
                                    class="button accent-button"
                                    v-ripple
                                    :class="{'fetching': downloadingWatermarked}"
                                >
                                    <i class="fas fa-download"></i>
                                    Original
                                </a>

                                <div class="button-dropdown">
                                    <button
                                        :disabled="original_url.length < 1"
                                        aria-label="Download No Watermark Video"
                                        class="button primary-button download-btn-nwm"
                                        v-ripple
                                        :class="{
                                            'active': showNwmDropdown
                                        }"
                                        @click="toggleNwmDropdown"
                                    >
                                        <i class="fas fa-download"></i>
                                        No Watermark
                                    </button>

                                    <div class="dropdown-content">
                                        <a
                                            v-for="(link, key) of original_url"
                                            :href="`/download?url=${encodeURIComponent(link)}&type=video&fileName=${encodeURIComponent(getFileTitle())}`"
                                            aria-label="Download No Watermark Video"
                                            target="_blank"
                                            class="dropdown-content__item"
                                            v-ripple
                                        >
                                            Download Link #{{ key + 1 }}
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </Transition>
                    </aside>
                </div>
            </div>
        </Transition>
    </div>
</template>

<script lang="ts">
import Loader       from "./Loader.vue"
import {Video}      from "~/store/modules/video"
import {toast}      from "~/utils/toast"
import ErrorHandler from "~/mixins/ErrorHandler"
import {mapActions} from "vuex"
import axios        from "~/plugin/axios"
import AdSpace      from "Components/Element/AdSpace.vue"
import {isEmpty}    from "lodash-es"

export default {
    name: "VideoBox",
    components: {AdSpace, Loader},
    mixins: [ErrorHandler],
    metaInfo() {

        if (!this.video) return {}

        return {
            title: isEmpty(this.video.title) ? "TikTok Video" : this.video.title
        }
    },
    data: () => ({
        fetched: false,
        fetching: false,
        original_url: [] as string[],
        shareShow: false,
        copyIcon: "copy",
        downloadingWatermarked: false,
        showNwmDropdown: false,
        abortController: null as AbortController
    }),
    watch: {
        video: {
            handler(value) {
                if (value) {
                    this.changeLock(true)
                } else {
                    this.changeLock(false)
                    this.original_url = null
                    this.fetched =
                        this.fetching =
                            this.downloadingWatermarked =
                                this.showNwmDropdown =
                                    false

                    this.abortController?.abort()

                    if (this.$route.name === "video")
                        this.$router.replace("/")
                }
            }
        }
    },
    computed: {
        loading() {
            return this.$store.getters["video/loading"]
        },
        video(): Video {
            return this.$store.getters["video/video"]
        },
        singleVideo(): boolean {
            return this.$store.getters["video/isSingle"]
        },
        shareAPI() {
            return navigator.share
        }
    },
    methods: {
        ...mapActions({
            "setVideo": "video/setVideo"
        }),
        async fetch() {

            try {

                this.abortController = new AbortController()

                this.fetching = true
                const {data} = await axios.get<{
                    original_url: string[]
                }>("/v1/tiktok-video/nwm", {
                    signal: this.abortController.signal,
                    params: {
                        id: this.video.video_id,
                        url: `https://tiktok.com/@${this.video.user.username}/video/${this.video.video_id}`
                    }
                })

                this.original_url = data.original_url
                this.fetched = true

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.fetching = false
            }
        },
        close() {
            this.setVideo(null)
            if (this.singleVideo && this.$route.name !== "home")
                this.$router.push({name: "home"})
        },
        share() {
            if (navigator.share) {
                navigator.share({
                    title: this.video.title,
                    url: this.video.share_url
                }).then(() => {
                    console.log("Thanks for sharing!")
                })
            }
        },
        copy() {
            if (!this.$refs["copy_input"])
                return
            this.$refs["copy_input"].select()
            document.execCommand("copy")
            this.copyIcon = "clipboard-check"
            toast("URL is copied to clipboard.", "fas fa-clipboard-check")
            setTimeout(() => {
                this.copyIcon = "copy"
            }, 2000)
        },
        changeLock(state = false) {
            state ?
                document.body.classList.add("scroll-lock") :
                document.body.classList.remove("scroll-lock")
        },
        async downloadMusic() {
            return this.downloadFile(
                this.video.music.url,
                this.video.music.title.replace(/\s/g, "") + ".mp3"
            )
        },
        getFileTitle() {
            return this.video.title.replace(/[^A-Za-z0-9]/g, "").substr(0, 32) + ".mp4"
        },
        async downloadFile(url: string, fileName: string) {

            try {
                const response = await fetch(url)
                const blob = await response.blob()
                const _url = window.URL.createObjectURL(blob)
                const a = document.createElement("a")
                a.href = _url
                a.download = fileName
                document.body.appendChild(a) // we need to append the element to the dom -> otherwise it will not work in firefox
                a.click()
                a.remove()  //afterwards we remove the element again
            } catch (e) {
                toast(e.message, "error")
            }
        },
        toggleNwmDropdown() {
            this.showNwmDropdown = !this.showNwmDropdown
        }
    }
}
</script>
