<template>
  <div class="collapse">
    <div class="header" @click="updateFocus()" v-ripple>
      <h2>
        <slot name="title"/>
      </h2>
      <i
          class="fas"
          :class="`fa-${show ? 'minus': 'plus'}`"
      >
      </i>
    </div>
    <TransitionCollapse>
      <div class="body" v-show="show">
        <p>
          <slot name="body"/>
        </p>
      </div>
    </TransitionCollapse>
  </div>
</template>
<script lang="ts">
import TransitionCollapse from "./TransitionCollapse.vue"

export default {
  name: "Collapse",
  components: {TransitionCollapse},
  props: {
    value: {
      type: [String, Number]
    },
    index: {
      type: [String, Number],
      required: true
    }
  },
  watch:{
    'value':{
      immediate: true,
      handler(value){
        this.focus = value
      }
    }
  },
  data: () => ({
    focus: 0
  }),
  computed: {
    show() {
      return this.focus === this.index
    }
  },
  methods: {
    updateFocus() {
      if (this.focus === this.index) {
        this.close()
        return
      }
      this.focus = this.index
      this.$emit("input", this.focus)
    },
    close() {
      this.focus = -1
      this.$emit("input", this.focus)
    }
  }
}
</script>