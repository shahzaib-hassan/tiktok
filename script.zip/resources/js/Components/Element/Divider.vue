<template functional>
   <span class="divider">
                        <svg width="96" height="7" viewBox="0 0 96 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="20.5" y="0.329163" width="55" height="6" rx="3"/>
                            <rect x="10.748" y="0.329163" width="6" height="6" rx="3"/>
                            <rect x="89.004" y="0.329163" width="6" height="6" rx="3"/>
                            <rect x="0.995972" y="0.329163" width="6" height="6" rx="3"/>
                            <rect x="79.252" y="0.329163" width="6" height="6" rx="3"/>
                        </svg>
                    </span>
</template>