<template>
    <div
        class="snackbar"
        ref="el"
    >
        <i
            v-if="['success','error','warning','info'].includes(icon)"
            class="fas"
            :class="`fa-${icon}`"
        ></i>
        <i v-else :class="icon"></i>
        <p>{{ toast.message }}</p>
    </div>
</template>

<script lang="ts">
import {PropType} from "vue"
import {Toast}    from "~/utils/toast"

export default {
    name: "ToastItem",
    props: {
        toast: Object as PropType<Toast>
    },
    mounted() {
        setTimeout(() => {
            this.onClose()
        }, 2000)
    },
    methods: {
        onClose() {
            this.$refs.el.addEventListener("animationend", this.onAnimEnd.bind(this))
            this.$refs.el.classList.add('hide')
        },
        onAnimEnd() {
            this.$refs.el.removeEventListener("animationend", this.onAnimEnd)
            this.$emit("close")
        }
    },
    computed: {
        icon(): string {
            if (this.toast.type === "success")
                return "check"
            else if (this.toast.type === "error")
                return "times"
            else if (this.toast.type === "info" || this.toast.type === "warning")
                return "info"
            else return this.toast.type
        }
    }
}
</script>
