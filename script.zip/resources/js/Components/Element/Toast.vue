<template>
    <div class="snackbar-container" v-show="hasToasts">
        <ToastItem
            v-for="(toast, key) of toasts.items"
            :toast="toast"
            :key="key"
            @close="()=> removeToast(key)"
        />
    </div>
</template>

<script lang="ts">
import {$TOASTS} from "~/utils/toast"
import ToastItem from "./ToastItem.vue"

export default {
    name: "Toast",
    components: {ToastItem},
    data: () => ({
        toasts: $TOASTS
    }),
    computed: {
        hasToasts() {
            return Object.keys(this.toasts.items).length > 0
        }
    },
    methods: {
        removeToast(key: string) {
            let items =  this.toasts.items
            delete items[key]
            this.toasts.items = items
            this.$forceUpdate()
        }
    }
}
</script>
