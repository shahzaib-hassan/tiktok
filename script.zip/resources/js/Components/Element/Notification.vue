<template>
    <div
        class="message-strip-container"
    >
        <Transition name="notification">
            <div
                v-show="!hidden"
                class="message-strip"
                ref="stripe"
            >
                <span class="progress" ref="progress"></span>
                <div class="text">
                    {{ notification.msg.message }}
                </div>
                <button
                    aria-label="Remove Message"
                    name="remove_message"
                    @click="hideAnim" class="style-none"
                >
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </Transition>

    </div>
</template>

<script lang="ts">
import {$NOTIFICATION}       from "~/utils/notification"
import {isElement, isString} from "lodash-es"

export default {
    name: "Notification",
    data: () => ({
        notification: $NOTIFICATION,
        timer: null,
        stripeAnim: null as Animation,
        progressAnim: null as Animation,
        duration: 5000,
        hide: false,
        hidden: true,
        reversed: false
    }),
    watch: {
        "notification": {
            deep: true,
            immediate: true,
            handler() {
                this.startTimer()
            }
        }
    },
    mounted() {
        const progressEl = this.$refs.progress
        const stripeEl = this.$refs.stripe
        if (isElement(progressEl)) {
            this.progressAnim = progressEl.animate([
                {width: "100%"},
                {width: "0%"}
            ], {
                duration: this.duration,
                iterations: 1,
                fill: "forwards"
            })
        }

        if (isElement(stripeEl)) {
            this.stripeAnim = stripeEl.animate([
                {opacity: 0, bottom: "-50px"},
                {opacity: 1, bottom: "0px"}
            ], {duration: 250, iterations: 1, fill: "both"})
            this.playHide()
        }
    },

    methods: {
        startTimer() {

            if (!isString(this.notification.msg.message))
                return

            clearTimeout(this.timer)

            this.reverseAnim()
            this.stripeAnim.play()
            this.hidden = this.hide = false

            if (this.progressAnim) {
                this.progressAnim.currentTime = 0
                this.progressAnim.play()
            }

            this.timer = setTimeout(() => {
                this.hideAnim()
            }, this.duration)
        },
        hideAnim() {
            clearTimeout(this.timer)
            this.hide = true
            this.reverseAnim(true)
            this.stripeAnim.play()
        },
        reverseAnim(state = false) {
            if (state && !this.reversed) {
                this.stripeAnim.reverse()
                this.reversed = true
            } else if (!state && this.reversed) {
                this.stripeAnim.reverse()
                this.reversed = false
            }
            this.stripeAnim.currentTime = 0
        },
        playHide() {
            this.stripeAnim?.addEventListener("finish", () => {
                if (!this.hide) return
                this.hidden = true
                this.hide = false
                this.$set(this.notification.msg, "message", null)
            })
        }
    }
}
</script>

<style scoped>

</style>
