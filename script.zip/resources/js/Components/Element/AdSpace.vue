<template>
    <div class="ad-container" v-if="shouldShow">

        <template v-if="ad.code === ''">
            <div :class="[`ad-${type}`]" class="ad" :style="adStyle">
                <template v-if="type === 'square'">
                    336x280<br/>
                    {{ ad.name | capitalize }} Ad
                </template>
                <template v-else-if="type === 'banner'">
                    728x90 {{ ad.name | capitalize }} Ad
                </template>
                <template v-else>
                    {{ ad.name | capitalize }} Ad
                </template>
            </div>
        </template>

        <template v-else>
            <Adsense :class="[`ad-${type}`]" :style="adStyle" v-bind="componentProps"/>
        </template>

    </div>
</template>

<script lang="ts">
import {Ad}     from "~/store/modules/settings"
import {isNull} from "lodash-es"

export default {
    name: "AdSpace",
    props: {
        type: {
            type: String,
            required: true
        },
        adStyle: {
            type: [String, Object, Array],
            required: false,
            default: ""
        }
    },
    computed: {
        ads(): Ad[] {
            return this.$store.getters["settings/ads"] ?? []
        },
        ad(): Ad | null {
            return this.ads.find((ad) => ad.name === this.type) ?? null
        },
        shouldShow(): boolean {
            if (isNull(this.ad)) return false
            return this.ad.status === "enabled"
        },
        componentProps() {
            if (isNull(this.ad)) return {}
            const template = document.createElement("div")
            template.innerHTML = this.ad.code
            if (template.children.length < 0) return {}
            const el = template.firstElementChild
            return el.getAttributeNames().reduce((attrs, name) => {
                attrs[name] = el.getAttribute(name)
                return attrs
            }, {})
        }
    }
}
</script>
