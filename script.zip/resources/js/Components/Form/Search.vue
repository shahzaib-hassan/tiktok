<template>
    <div class="search">
        <input
            @keydown.enter="searchVideo()"
            v-model="searchQuery"
            :readonly="processing"
            aria-label="Search Video"
            type="text"
            class="style-none search-input"
            placeholder="Enter video url"
        >
        <i class="fas fa-search search-icon"></i>
        <div class="actions">
            <button
                v-if="canPaste && !processing"
                @click.prevent="paste"
                aria-label="Paste Clipboard Text"
                class="style-none copy-icon"
            >
                <i class="fas fa-copy"></i>
            </button>
            <div
                v-if="processing"
                class="spinner-container border-left"
            >
                <span class="spinner"></span>
            </div>
            <button
                v-else
                @click="searchVideo()"
                aria-label="Search Video"
                class="style-none search-text border-left"
            >
                Search
            </button>
        </div>
    </div>
</template>
<script lang="ts">
import Searchable from "~/mixins/Searchable"

export default {
    name: "Search",
    mixins: [Searchable],
    data: () => ({
        isSingle: true
    })
}
</script>
