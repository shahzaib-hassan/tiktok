<template>
    <div
        class="search"
        :class="{'focus':focus}"
    >
        <input
            v-model="searchQuery"
            @keydown.enter="searchVideo()"
            :readonly="processing"
            type="text"
            aria-label="Search Video"
            class="style-none search-input"
            placeholder="Enter video url"
        >
        <i class="fas fa-search search-icon"></i>
        <div class="actions">
            <button
                v-if="canPaste && !processing"
                @click.prevent="paste"
                aria-label="Paste Clipboard Text"
                class="style-none copy-icon"
            >
                <i class="fas fa-copy"></i>
            </button>
            <div
                v-if="processing"
                class="spinner-container border-left"
            >
                <span class="spinner"></span>
            </div>
            <button
                v-else
                @click="close()"
                aria-label="Search Video"
                class="style-none close-icon border-left"
            >
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
</template>
<script>
import Searchable from '~/mixins/Searchable'

export default {
    mixins: [Searchable],
    props: {
        value: [Boolean]
    },
    data: () => ({
        focus: false,
        isSingle: false
    }),
    watch: {
        'value': {
            immediate: true,
            handler(value) {
                this.focus = value
            }
        }
    },
    methods: {
        close() {
            if (this.processing)
                return
            this.focus = false
            this.$emit('input', this.focus)
        }
    }
}
</script>
