import {PluginObject} from "vue"
import Adsense from 'vue-google-adsense/dist/Adsense.min.js'

export default {
    install(Vue) {
        Vue.use(require("vue-script2"))

        Vue.use(Adsense)
        // Vue.use(Ads.InArticleAdsense)
        // Vue.use(Ads.InFeedAdsense)
        //.
    }
} as PluginObject<any>
