import {PluginObject}              from "vue"
import {DateTime}                  from "luxon"
import {capitalize as _capitalize} from "lodash"

export function diffForHuman(value: number): string {
	if (!value) return ""
	return DateTime.fromMillis(value).toRelative({style: "short", round: true})
}

export function capitalize(value: string): string {
	return _capitalize(value)
}

export function balance(value: number): string {
	if (value > 999 && value < 1000000) {
		return (value / 1000).toFixed(0) + "K" // convert to K for number from > 1000 < 1 million
	} else if (value > 1000000) {
		return (value / 1000000).toFixed(0) + "M" // convert to M for number from > 1 million
	} else if (value < 900) {
		return value.toString()// if value < 1000, nothing to do
	}
}

export function linkiefied(value: string): string {
	return value.replace(/(#([^ #]+)|@([^ @]+))/g, (_, text, match) => {
		return _[0] === "#" ?
			`<a href="https://www.tiktok.com/tag/${match}" referrerpolicy="no-referrer" target="_blank">${text}</a>` :
			`<a href="https://www.tiktok.com/@${match}" referrerpolicy="no-referrer" target="_blank">${text}</a>`
	})
}

export default {
	install(Vue) {
		Vue.filter("linkiefied", linkiefied)
		Vue.filter("balance", balance)
		Vue.filter("capitalize", capitalize)
		Vue.filter("diffForHuman", diffForHuman)
	}
} as PluginObject<any>
