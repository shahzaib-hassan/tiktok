<template>
    <section class="page-container-full" v-if="page">
        <div class="page-hero">
            <div class="fluid">
                <h1>{{ page.title }}</h1>
                <h2>{{ page.excerpt }}</h2>
            </div>
        </div>
        <div class="fluid">
            <article class="page-article" v-html="page.body">
            </article>
        </div>
    </section>
</template>

<script lang="ts">

import {Page}   from "~/store/modules/pages"
import {isNull} from "lodash-es"

export default {
    name: "Page",
    metaInfo() {
        return {
            title: this.page.title
        }
    },
    computed: {
        page(): Page {
            let slug = this.$route.params.slug
            return this.$store.getters["pages/page"](slug)
        }
    },
    mounted() {
        let pages = this.$store.getters["app/pages"]
        if (!pages)
            return
        if (isNull(this.page))
            this.$router.push({name: "Page404"})
    }
}
</script>
