<template>
    <div class="page-404">
        <h1>
            <span>4</span>
            <img src="/imgs/404/404_emoji.png" alt="404">
            <span>4</span>
        </h1>
        <p class="desc">
            Couldn't find this page
        </p>
        <p class="footer">
            <RouterLink
                :to="{name: 'home'}"
            >
                Take me back home
            </RouterLink>
        </p>
    </div>
</template>

<script lang="ts">
    export default {
        name: "Page404",
        metaInfo: {
            title: 'Page not Found.'
        },
    }
</script>
