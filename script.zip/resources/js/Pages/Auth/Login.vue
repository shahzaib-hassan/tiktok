<template>
    <div class="card login-card">
        <form @submit.prevent="login">
            <div class="form-control">
                <label for="email">Admin Email</label>
                <input type="email" id="email" v-model="user.email" placeholder="Enter Email" required autofocus
                       autocomplete>
            </div>
            <div class="form-control mt">
                <label for="password">Password</label>
                <input type="password" id="password" v-model="user.password" placeholder="Password" required
                       autocomplete>
            </div>
            <button :disabled="!valid || processing" class="submit-button mt">
                {{ processing ? 'Authenticating' : 'Login' }}
            </button>
        </form>
    </div>
</template>

<script lang="ts">
import {mapActions, mapGetters} from "vuex"

export default {
    name: "Login",
    metaInfo: {
        title: "Login"
    },
    data: () => ({
        user: {
            email: "",
            password: ""
        }
    }),
    computed: {
        ...mapGetters({
            "processing": "auth/processing"
        }),
        valid() {
            return /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/
                    .test(this.user.email)
                && this.user.password.length > 2
        }
    },
    methods: {
        ...mapActions({
            "loginUser": "auth/login"
        }),
        login() {
            if (!this.valid)
                return
            this.loginUser(this.user)
        }
    }
}
</script>
