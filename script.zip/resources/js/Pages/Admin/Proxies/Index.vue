<template>
    <div class="card setting-card">
        <h3 class="with-button">
            Proxies

        </h3>
        <template v-if="!fetching">
            <form @submit.prevent>
                <div class="inputGroupProxy">
                    <div class="form-control">
                        <input
                            aria-label="Add Proxy"
                            type="text"
                            id="proxy"
                            v-model="proxy"
                            :disabled="processing"
                            placeholder="Enter Proxy"
                            required
                            autofocus
                        >
                        <p class="input_tooltip">
                            Proxy should match following pattern: https?://ip:port OR https?://username:password@ip:port
                        </p>
                    </div>
                    <button
                        v-ripple
                        class="style-none add-button"
                        :disabled="processing"
                        @click.prevent="addProxy"
                    >
                        {{ processing ? 'Checking' : 'Add' }}
                        <i
                            class="space fas"
                            :class="processing ? 'fa-spinner fa-spin':'fa-plus'"
                        ></i>
                    </button>
                </div>
            </form>

            <div v-if="!proxies.length" class="no-item">
                {{ can_view ? 'No proxies found.' : 'You are not allowed to view this.' }}
            </div>

            <div v-if="proxies.length" class="proxiesList">

                <div
                    class="inputGroupProxy"
                    v-for="(proxy,index) in proxies"
                    :key="index"
                >
                    <div class="form-control">
                        <input
                            :value="proxy"
                            aria-label="Add Proxy"
                            type="text"
                            readonly
                        >
                    </div>
                    <button
                        @click.prevent="deleteProxy(index)"
                        v-ripple
                        :disabled="processing || deletingIndex === index"
                        class="style-none delete-button py"
                    >
                        <i class="fas fa-times"></i>
                    </button>
                </div>

            </div>
        </template>
        <div v-else class="fetching-div">
            Loading Proxies
        </div>

    </div>
</template>

<script lang="ts">

import {User}              from "~/store/modules/auth"
import {isArray, isString} from "lodash-es"
import axios               from "~/plugin/axios"
import ErrorHandler        from "~/mixins/ErrorHandler"
import {toast}             from "~/utils/toast"
import {notify}            from "~/utils/notification"
import {getAxiosAuth}      from "~/utils/axiosAuth"

export default {
    name: "Proxies",
    mixins: [ErrorHandler],
    metaInfo: {
        title: "Proxies Settings"
    },
    data: () => ({
        processing: false,
        proxy: "",
        proxies: [],
        fetching: false,
        deletingIndex: null,
        can_view: true
    }),
    watch: {
        auth: {
            immediate: true,
            handler(value: User) {
                if (isString(value?.email))
                    this.onAuthenticated()
            }
        }
    },
    computed: {
        auth(): User {
            return this.$store.getters["auth/user"]
        }
    },
    methods: {
        async onAuthenticated() {
            if (!this.auth.isAdmin) {
                this.can_view = false
                return
            }
            await this.getProxies()
        },
        async getProxies() {
            try {
                this.fetching = true
                let {data} = await axios.get<{ proxies: string[] }>("/proxies", getAxiosAuth())
                let proxies = data.proxies

                if (isArray(proxies))
                    this.proxies = proxies

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.fetching = false
            }

        },
        async addProxy(e: PointerEvent) {

            if (this.proxies.indexOf(this.proxy) !== -1)
                return toast("This proxy is already in list.", "error")

            if (!this.validate(this.proxy))
                return toast("The proxy is invalid.")

            this.processing = true

            try {
                await axios.post("proxies", {
                    proxy: this.proxy,
                    forced: e.shiftKey
                }, getAxiosAuth())

                this.proxies = [
                    ...this.proxies,
                    this.proxy
                ]

                this.proxy = ""

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        },
        async deleteProxy(index) {

            let proxy = this.proxies[index] || null

            if (typeof proxy === "undefined" || proxy === null)
                return notify("Proxy not found. Try again.")

            this.deletingIndex = index

            try {
                await axios.delete("/proxies", {
                    params: {proxy},
                    ...getAxiosAuth()
                })

                this.proxies.splice(index, 1)

            } catch (e) {
                this.handleAxiosError(e)
            }

            this.deletingIndex = null
        },
        validate(value) {
            return /^https?:\/\/[^\n]+:[^\n]+$/.test(value)
                || /^https?:\/\/[^\n]+:[^\n]+@\/[^\n]+:[^\n]+$/.test(value)
        }
    }
}
</script>
