<template>
    <div class="card setting-card without-x-padding">
        <h3 class="with-button">
            Pages
            <RouterLink
                v-ripple
                :to="{name: 'admin.pages.modify',params: {action: 'add'}}"
                class="style-none add-button"
            >
                Add New <i class="space fas fa-plus"></i>
            </RouterLink>
        </h3>
        <table>
            <col style="width:5%">
            <col style="width:50%">
            <col style="width:15%">
            <col style="width:15%">
            <col style="width:20%">
            <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(page, index) in pages" :key="index">
                <td>{{ page.id }}</td>
                <td class="start">{{ page.title }}</td>
                <td>{{ page.created_at | diffForHuman }}</td>
                <td>{{ page.updated_at | diffForHuman }}</td>
                <td class="end">
                    <RouterLink
                        v-ripple
                        :to="{name: 'admin.pages.modify',params: {action: 'edit',slug: page.slug}}"
                        class="btn style-none edit-button"
                    >
                        <i class="fas fa-edit"></i>
                    </RouterLink>
                    <button
                        v-ripple
                        @click="deletePage(page.id)"
                        class="btn style-none delete-button py"
                    >
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</template>

<script lang="ts">
import {mapActions} from "vuex"
import {Page}       from "~/store/modules/pages"
import {toast}      from "~/utils/toast"
import axios        from "~/plugin/axios"
import ErrorHandler from "~/mixins/ErrorHandler"

export default {
    name: "PagesList",
    mixins: [ErrorHandler],
    metaInfo: {
        title: 'Pages'
    },
    computed: {
        pages(): Page[] {
            return this.$store.getters["pages/pages"]
        }
    },
    mounted() {
        this.loadPages()
    },
    methods: {
        ...mapActions({
            "loadPages": "pages/loadPages",
            "setPages": "pages/setPages"
        }),
        async deletePage(id) {
            if (!confirm("Are you sure?!"))
                return

            try {
                const {data} = await axios.delete<{pages: Page[]}>("pages", {params: {id}})
                this.setPages(data.pages)
                toast("Page deleted!", "success")
            } catch (e) {
                this.handleAxiosError(e)
            }
        }
    }
}
</script>
