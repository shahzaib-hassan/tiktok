<template>
    <div class="card setting-card">
        <form @submit.prevent="post">
            <h3 class="with-button">
                {{ isAdd ? 'Add Page' : 'Edit Page' }}
                <button :disabled="processing" class="style-none add-button">
                    <template v-if="processing">
                        {{ isAdd ? 'Publishing' : 'Saving' }}
                        <i class="space fas fa-spinner fa-spin"></i>
                    </template>
                    <template v-else>
                        {{ isAdd ? 'Publish' : 'Save' }}
                        <i class="space fas fa-save"></i>

                    </template>
                </button>
            </h3>
            <div class="form-control">
                <label for="page_title">Title</label>
                <input
                    v-model="page.title"
                    @input="createSlug"
                    type="text"
                    id="page_title"
                    placeholder="Enter Page Title"
                    required
                    autofocus
                >
            </div>
            <div class="form-control mt">
                <label for="page_slug">Slug</label>
                <input
                    v-model="page.slug"
                    :disabled="!isAdd"
                    type="text"
                    id="page_slug"
                    placeholder="Enter Page Slug"
                    required
                >
            </div>
            <div class="form-control mt">
                <label for="page_excerpt">Excerpt</label>
                <textarea
                    v-model="page.excerpt"
                    name="page_excerpt"
                    id="page_excerpt"
                    required
                    cols="5"
                    rows="4"
                ></textarea>
            </div>
            <div class="form-control mt">
                <label for="page_body">Body</label>
                <vue-editor
                    v-model="page.body"
                    name="page_body"
                    useCustomImageHandler
                    @image-added="uploadImage"
                    required
                    id="page_body"
                ></vue-editor>
            </div>
        </form>
    </div>
</template>

<script lang="ts">
import {mapActions}           from "vuex"
import ImageUpload            from "~/mixins/ImageUpload"
import {cloneDeep, kebabCase} from "lodash-es"
import {Page}                 from "~/store/modules/pages"
import {toast}                from "~/utils/toast"
import {sanitize}             from "~/utils/helpers"
import ErrorHandler           from "~/mixins/ErrorHandler"
import axios                  from "~/plugin/axios"
import {getAxiosAuth}         from "~/utils/axiosAuth"
import {VueEditor}            from "vue2-editor"

export default {
    name: "PagesCreate",
    mixins: [ImageUpload, ErrorHandler],
    components: {VueEditor},
    metaInfo() {
        return {
            title: this.isAdd ? "Create new Page" : "Update Page"
        }
    },
    data: () => ({
        page: {
            title: "",
            slug: "",
            excerpt: "",
            body: ""
        },
        processing: false
    }),
    computed: {
        pages(): Page[] {
            return this.$store.getters["pages/pages"]
        },
        isAdd() {
            return this.$route.params.action === "add"
        }
    },
    mounted() {
        let slug = this.$route.params.slug?.trim()
        if (slug) {
            let page = this.pages.find((page) => page.slug.trim() === slug.trim())
            if (!page)
                return this.redirectToList()
            this.page = cloneDeep(page)
        }
    },
    methods: {
        ...mapActions({
            "updatePage": "pages/updatePage"
        }),
        redirectToList() {
            toast("Page slug is invalid!", "error")
            this.$router.push({name: "admin.pages.list"})
        },
        validate(): boolean {
            if (this.page.body.length < 1) {
                toast("Please Fill all fields!", "error")
                return false
            }

            const invalid_fields = []

            const page = {
                title: this.page.title,
                excerpt: this.page.excerpt,
                slug: this.page.slug
            }
            Object.entries(page).forEach((v: [string, string]) => {
                if (sanitize(v[1])) {
                    invalid_fields.push(v[0])
                }
            })

            if (invalid_fields.length > 0) {
                let multiple = invalid_fields.length > 1 ? "fields were" : "field is"
                let attribute = invalid_fields.join(", ")
                toast(`${attribute} ${multiple} invalid. Only text is allowed.`, "error")
                return false
            }

            return true
        },
        async post() {

            if (!this.validate())
                return

            try {
                this.processing = true

                const endpoint = this.isAdd ? "pages" : `pages/${this.page.slug}`

                const {data} = await axios.post<{ page: Page }>(endpoint, this.page, getAxiosAuth())
                this.updatePage(data.page)
                await this.$router.push({name: "admin.pages.list"})
            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        },
        createSlug() {
            if (!this.isAdd)
                return
            this.page.slug = kebabCase(this.page.title)
        }
    }
}
</script>
