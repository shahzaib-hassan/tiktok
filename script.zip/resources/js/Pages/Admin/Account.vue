<template>
    <div class="card setting-card">
        <form @submit.prevent="submit">
            <h3 class="with-button">
                Admin Account
                <button type="submit" v-ripple :disabled="processing" class="style-none add-button">
                    {{ processing ? 'Saving' : 'Save' }}
                    <i class="space fas" :class="processing ? 'fa-spinner fa-spin':'fa-save'"></i>
                </button>
            </h3>
            <div class="form-control">
                <label for="email">Email</label>
                <input type="email" id="email" v-model="user.email" placeholder="Admin Email" required
                       autocomplete="email"
                       autofocus>
            </div>
            <div class="form-control mt">
                <label for="password">Password</label>
                <input type="password" id="password" v-model="user.password" placeholder="Admin Password"
                       autocomplete="new-password">
            </div>
        </form>
    </div>
</template>

<script lang="ts">

import {mapActions}   from "vuex"
import {sanitize}     from "~/utils/helpers"
import {toast}        from "~/utils/toast"
import {User}         from "~/store/modules/auth"
import axios          from "~/plugin/axios"
import ErrorHandler   from "~/mixins/ErrorHandler"
import {getAxiosAuth} from "~/utils/axiosAuth"
import {cloneDeep}    from "lodash-es"

export default {
    name: "Account",
    mixins: [ErrorHandler],
    metaInfo: {
      title: 'Account Settings'
    },
    data: () => ({
        user: {
            email: "",
            password: ""
        },
        processing: false
    }),
    created() {
        this.user = {
            email: cloneDeep(this.auth).email,
            password: ""
        }
    },
    computed: {
        auth(): User {
            return this.$store.getters["auth/user"]
        }
    },
    methods: {
        ...mapActions({
            "updateUser": "auth/updateUser"
        }),
        validate(): boolean {
            if (!this.auth)
                return false
            if (!this.auth.isAdmin) {
                toast("Permission Denied!", "error")
                return false
            }

            const invalid_fields = []
            Object.entries(this.user).forEach((v: [string, string]) => {
                if (sanitize(v[1])) {
                    invalid_fields.push(v[0])
                }
            })

            if (invalid_fields.length > 0) {
                const multiple = invalid_fields.length > 1 ? "fields were" : "field is"
                const attribute = invalid_fields.join(", ")
                toast(`${attribute} ${multiple} invalid. Only text is allowed.`)
                return false
            }

            return true
        },
        async submit() {

            if (!this.validate())
                return

            try {
                this.processing = true

                const {data} = await axios.post<{ user: User }>("/account", this.user, getAxiosAuth())
                toast("User Updated", "success")
                this.updateUser(data.user)
            } catch (e) {
               this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        }
    }
}
</script>
