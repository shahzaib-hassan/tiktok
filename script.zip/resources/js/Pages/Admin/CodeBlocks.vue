<template>
    <div class="card setting-card">
        <form @submit.prevent="save">
            <h3 class="with-button">
                Extra Code
                <button type="submit" :disabled="processing" class="style-none add-button">
                    {{ processing ? 'Saving' : 'Save' }}
                    <i class="space fas" :class="processing ? 'fa-spinner fa-spin':'fa-save'"></i>
                </button>
            </h3>
            <div class="form-control">
                <label for="header_code_block">This code will go to &lt;head&gt; tag</label>
                <textarea
                    name="header_code_block"
                    id="header_code_block"
                    v-model="headerCodeBlock"
                    cols="5"
                    rows="5"
                ></textarea>
            </div>
            <h3 class="mt with-button">Ads Code
                <button @click.prevent="pushAd" v-ripple class="style-none add-button">
                    <i class="fas fa-plus"></i>
                </button>
            </h3>
            <TransitionGroup
                enter-active-class="animated d-3 fadeIn"
                leave-active-class="animated d-2 fadeOut"
            >
                <div
                    class="form-control mb"
                    v-for="(ad, index) in ads"
                    :key="index"
                >
                    <div class="network-grid">
                        <select v-model="ad.name">
                            <option
                                v-for="(name,index) in adPlacements"
                                :key="index"
                                :value="name"
                            >
                                {{ name }}
                            </option>
                        </select>
                        <select v-model="ad.network">
                            <option
                                v-for="(network,index) in networks"
                                :key="index"
                                :value="network"
                            >
                                {{ network | capitalize }}
                            </option>
                        </select>
                        <select v-model="ad.status">
                            <option value="enabled">Enabled</option>
                            <option value="disabled">Disabled</option>
                        </select>
                        <button :disabled="[0,1].includes(index)" @click.prevent="removeAdd(index)"
                                class="style-none delete-button py">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <textarea
                        :name="index"
                        :id="index"
                        v-model="ad.code"
                        cols="5"
                        rows="5"
                    ></textarea>
                </div>
            </TransitionGroup>
        </form>
    </div>
</template>

<script lang="ts">
import {User}              from "~/store/modules/auth"
import {Ad}                           from "~/store/modules/settings"
import {cloneDeep, isArray, isString} from "lodash-es"
import {toast}                        from "~/utils/toast"
import {sanitizeComment}   from "~/utils/helpers"
import axios               from "~/plugin/axios"
import ErrorHandler        from "~/mixins/ErrorHandler"
import {getAxiosAuth}      from "~/utils/axiosAuth"

export default {
    name: "CodeBlocks",
    mixins: [ErrorHandler],
    metaInfo: {
        title: 'Code Blocks'
    },
    data: () => ({
        networks: ["adsense"],
        ads: [] as Ad[],
        headerCodeBlock: "",
        processing: false,
        adPlacements: [
            'square', 'banner', 'below-search', 'above-steps', 'below-steps', 'above-how-to-download',
            'below-how-to-download', 'above-faq'
        ]
    }),
    created() {
        if (this.auth.isAdmin) {
            const ads = this.$store.getters["settings/ads"] as Ad[]
            const headerCodeBlock = this.$store.getters["settings/headerCodeBlock"] as string
            if (isArray(ads)) this.ads = cloneDeep(ads)
            if (isString(headerCodeBlock)) this.headerCodeBlock = cloneDeep(headerCodeBlock)
        }
    },
    computed: {
        auth(): User {
            return this.$store.getters["auth/user"]
        }
    },
    methods: {
        validate(): boolean {
            if (!this.auth || !this.auth?.isAdmin) {
                toast("Permission Denied!", "error")
                return false
            }

            let invalid_fields = []

            if (sanitizeComment(this.headerCodeBlock))
                invalid_fields.push("headerCodeBlock")

            this.ads.forEach((ad) => {
                if (sanitizeComment(ad.code)) {
                    invalid_fields.push(ad.name)
                }
            })

            if (invalid_fields.length > 0) {
                let multiple = invalid_fields.length > 1 ? "fields were" : "field is"
                let attribute = invalid_fields.join(", ")
                toast(
                    `${attribute} ${multiple} invalid. Comments are not allowed.`,
                    "error"
                )
                return false
            }

            return true
        },
        async save() {

            if (!this.validate())
                return

            try {
                this.processing = true
                await axios.post("/code-blocks", {
                    headerCodeBlock: btoa(this.headerCodeBlock),
                    ads: this.ads
                }, getAxiosAuth())

                toast("Codes updated successfully!", "success")
                await Promise.all([
                    this.$store.dispatch("settings/updateAds", cloneDeep(this.ads)),
                    this.$store.dispatch("settings/updateHeaderCodeBlock", cloneDeep(this.headerCodeBlock))
                ])

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        },
        removeAdd(index) {
            this.ads.splice(index, 1)
        },
        pushAd() {
            this.ads.push({
                name: "",
                code: "",
                network: this.networks[0],
                status: "enabled"
            })
        }
    }
}
</script>
