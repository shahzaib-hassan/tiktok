<template>
    <div class="recent-search">
        <div class="header">
            Recent Searches
        </div>
        <div ref="top_item_list_container" class="body">
            <div v-if="Object.keys(records).length > 0" class="items">
                <div v-for="(item, index) in records" :key="index" v-ripple class="item">
                    <img :src="item.user.cover" :alt="item.user.name">
                    <p>{{ item.caption }}</p>
                    <a @click.prevent="openVideo(item)">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>
            </div>
            <div v-else-if="loading" class="spinner-container max-size center">
                <span class="spinner"></span>
            </div>
            <div v-else class="no-records">
                There are no records!
            </div>
        </div>
    </div>
</template>

<script lang="ts">

import VideoContainer from "~/mixins/VideoContainer"
import ErrorHandler   from "~/mixins/ErrorHandler"
import axios          from "~/plugin/axios"
import {Video}        from "~/store/modules/video"
import cookies        from "js-cookie"

export default {
    name: "RecentSearches",
    mixins: [VideoContainer, ErrorHandler],
    data: () => ({
        getter: "video/recent",
        ref_item: "top_item_list_container"
    }),
    mounted() {
        this.loadVideos()
    },
    methods: {
        async loadVideos() {
            try {
                this.loading = true

                const {data} = await axios.get<{
                    videos: Video[]
                }>("recent", {
                    headers: {
                        "Authorization": `Bearer ${cookies.get("token")}`
                    }
                })

                await this.$store.dispatch("video/setRecent", data.videos ?? [])

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.loading = false
            }
        }
    }
}
</script>
