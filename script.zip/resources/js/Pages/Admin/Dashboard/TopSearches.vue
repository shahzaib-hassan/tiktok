<template>
    <div class="top-search">
        <div class="header">
            Top Searches
        </div>
        <div ref="items_list_container" class="body">
            <div v-if="Object.keys(records).length > 0" class="items">
                <div class="items">
                    <div v-ripple class="item" v-for="(item, index) in records" :key="index" @click="openVideo(item)">
                        <img :src="item.cover" :alt="item.title">
                        <div class="details">
                            <img :src="item.user.cover" :alt="item.user.name">
                            <p><i class="fas fa-play"></i> {{ item.stats.play | balance }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else-if="loading" class="spinner-container max-size center">
                <span class="spinner"></span>
            </div>
            <div v-else class="no-records">
                There are no records!
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import VideoContainer from "~/mixins/VideoContainer"
import ErrorHandler   from "~/mixins/ErrorHandler"
import axios          from "~/plugin/axios"
import {Video}        from "~/store/modules/video"
import cookies        from "js-cookie"

export default {
    name: "topSearches",
    mixins: [VideoContainer, ErrorHandler],
    data: () => ({
        getter: "video/trending",
        ref_item: "items_list_container"
    }),
    mounted() {
        this.loadVideos()
    },
    methods: {
        async loadVideos() {
            try {
                this.loading = true

                const {data} = await axios.get<{
                    videos: Video[]
                }>("trending", {
                    headers: {
                        "Authorization": `Bearer ${cookies.get("token")}`
                    }
                })

                await this.$store.dispatch("video/setTrending", data.videos ?? [])

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.loading = false
            }
        }
    }
}
</script>
