<template>
    <div class="card setting-card">
        <form @submit.prevent="save">
            <h3 class="with-button">
                Menu Customization
                <button v-ripple class="style-none add-button">
                    {{ processing ? 'Saving' : 'Save' }}
                    <i class="space fas" :class="processing ? 'fa-spinner fa-spin':'fa-save'"></i>
                </button>
            </h3>
            <div class="menu-items">
                <Draggable
                    @change="update"
                    v-model="menus"
                    draggable=".item"
                >
                    <div
                        class="item" v-for="(menu, index) in menus"
                        :key="menu.id"
                        draggable="true"
                    >
                        <i class="fas fa-align-justify"></i>
                        <input
                            aria-label="Menu Text"
                            type="text"
                            class="form-input bg"
                            v-model="menu.text"
                            placeholder="Menu Text"
                            required
                        >
                        <input
                            aria-label="Menu Link"
                            v-if="menu.external"
                            type="text"
                            class="form-input bg"
                            v-model="menu.link"
                            placeholder="Menu Link/ Page Slug"
                            required
                        >
                        <select
                            class="form-input bg"
                            aria-label="Menu Link"
                            name="link"
                            v-model="menu.link"
                            v-else
                        >
                            <option
                                v-for="(page, key) in pages"
                                :value="page.slug"
                                :key="key"
                            >
                                {{ page.title }}
                            </option>
                        </select>
                        <select
                            aria-label="Is External"
                            class="form-input bg"
                            v-model="menu.external"
                            name="is-external"
                            :id="`is-external-${menu.id}`"
                        >
                            <option :value="true">External</option>
                            <option :value="false">Internal</option>
                        </select>
                        <button
                            @click.prevent="removeMenu(index)"
                            v-ripple
                            class="style-none delete-button py"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div v-if="menus.length < 1" class="no-item">
                        Please Add menu from Add button below 👇
                    </div>
                    <button
                        class="style-none add-button mt"
                        v-ripple
                        @click.prevent="pushMenu"
                        slot="footer"
                    >
                        Add <i class="space fas fa-plus"></i>
                    </button>

                </Draggable>
            </div>
        </form>
    </div>
</template>

<script lang="ts">
import Draggable             from "vuedraggable"
import {Menu}                from "~/store/modules/settings"
import {cloneDeep, isArray}  from "lodash-es"
import {Page}                from "~/store/modules/pages"
import {arrayMove, sanitize} from "~/utils/helpers"
import {toast}               from "~/utils/toast"
import axios                 from "~/plugin/axios"
import ErrorHandler          from "~/mixins/ErrorHandler"
import {getAxiosAuth}        from "~/utils/axiosAuth"

export default {
    name: "Menu",
    mixins: [ErrorHandler],
    metaInfo: {
        title: "Menu Settings"
    },
    components: {Draggable},
    data: () => ({
        menus: [] as Menu[],
        processing: false
    }),
    created() {
        const menus = this.$store.getters["settings/menus"]
        if (isArray(menus)) this.menus = cloneDeep(menus)
    },
    computed: {
        top() {
            if (this.menus.length < 1)
                return null
            return this.menus
                .reduce((prev, current) => (prev.id > current.id) ? prev : current)
        },
        pages(): Page[] {
            return this.$store.getters["pages/pages"] || []
        }
    },
    methods: {
        pushMenu() {
            let newId = this.top ? this.top.id + 1 : 0
            this.menus.push({
                id: newId,
                text: "",
                link: "",
                external: false
            })
        },
        update({moved}: { moved: { oldIndex: number, newIndex: number } }) {
            arrayMove(this.menus, moved.oldIndex, moved.newIndex)
        },
        removeMenu(index: number) {
            this.menus.splice(index, 1)
        },
        validate(): boolean {
            let invalid_fields = []
            this.menus.forEach((menu) => {
                if (sanitize(menu.text) || sanitize(menu.link)) {
                    invalid_fields.push(menu.text)
                }
            })

            if (invalid_fields.length > 0) {
                let multiple = invalid_fields.length > 1 ? "fields were" : "field is"
                let attribute = invalid_fields.join(", ")
                toast(
                    `${attribute} ${multiple} invalid. Only text is allowed.`,
                    "error"
                )
                return false
            }

            return true
        },
        async save() {

            if (!this.validate())
                return

            try {
                this.processing = true
                await axios.post("/menus", {menus: this.menus}, getAxiosAuth())
                toast("Menus updated successfully!", "success")
                await this.$store.dispatch("settings/updateMenus", cloneDeep(this.menus))

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        }
    }
}
</script>
