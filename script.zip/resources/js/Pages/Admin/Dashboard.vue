<template>
  <div class="dashboard-grid-group">
    <RecentSearches/>
    <TopSearches/>
  </div>
</template>

<script lang="ts">
import RecentSearches from "./Dashboard/RecentSearches.vue"
import TopSearches    from "./Dashboard/TopSearches.vue"

export default {
  name: "Dashboard",
  components: {TopSearches, RecentSearches},
    metaInfo: {
        title: 'Dashboard'
    },
}
</script>
