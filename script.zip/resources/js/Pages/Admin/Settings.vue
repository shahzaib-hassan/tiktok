<template>
    <div class="card setting-card">
        <form @submit.prevent="save">
            <h3 class="with-button">
                General Settings
                <button
                    v-ripple
                    :disabled="processing"
                    class="style-none add-button"
                >
                    {{ processing ? 'Saving' : 'Save' }}
                    <i
                        class="space fas"
                        :class="processing ? 'fa-spinner fa-spin':'fa-save'"
                    ></i>
                </button>
            </h3>
            <div class="form-control">
                <label for="api_ver">API Version</label>
                <select name="api_ver" v-model="app.api_version" id="api_ver">
                    <option value="wrapper" selected>Wrapper API</option>
                </select>
            </div>
            <div class="form-control mt">
                <label for="site_name">Site Name</label>
                <input
                    v-model="app.name"
                    type="text"
                    id="site_name"
                    placeholder="Enter Site Name"
                    required
                    autofocus
                >
            </div>
            <div class="form-control mt">
                <label for="site_desc">Site Description</label>
                <textarea
                    v-model="app.desc"
                    name="site_desc"
                    id="site_desc"
                    required
                    cols="5"
                    rows="5"
                ></textarea>
            </div>
            <div class="form-control mt">
                <label for="site_keywords">Site Keywords</label>
                <textarea
                    v-model="app.keywords"
                    name="site_keywords"
                    id="site_keywords"
                    required
                    cols="5"
                    rows="2"
                ></textarea>
            </div>

            <h3 class="mt with-button">Social Links
                <button
                    :disabled="socials.length > 6"
                    class="style-none add-button"
                    @click.prevent="addLink"
                >
                    <i class="fas fa-plus"></i>
                </button>
            </h3>


            <div class="social-links">
                <TransitionGroup
                    enter-active-class="animated fadeIn d-3"
                    leave-active-class="animated fadeOut d-3"
                >
                    <div
                        v-for="(link, key) in socials"
                        :key="key"
                        class="social-link-grid"
                    >
                        <div class="form-control">
                            <select
                                :name="link.text"
                                v-model="link.text"
                                :id="link.text"
                            >
                                <option
                                    v-for="(brand, key) in brands"
                                    :key="key"
                                    :disabled="isSelected(brand)"
                                    :value="brand"
                                >
                                    {{ brand | capitalize }}
                                </option>
                            </select>
                        </div>
                        <div class="form-control">
                            <input
                                v-model="link.link"
                                aria-label="Link Url"
                                type="text"
                                name="link_url"
                                required
                                placeholder="Enter Link Url"
                            >
                        </div>
                        <button
                            @click.prevent="deleteLink(index)"
                            class="style-none delete-button"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>

                </TransitionGroup>
                <div
                    class="no-social-links"
                    v-if="socials.length < 1"
                >
                    No Social Links
                </div>
            </div>


        </form>
    </div>
</template>

<script lang="ts">
import {Meta}               from "~/store/modules/app"
import {Social}             from "~/store/modules/settings"
import {cloneDeep, isArray} from "lodash-es"
import {toast}              from "~/utils/toast"
import ErrorHandler         from "~/mixins/ErrorHandler"
import axios                from "~/plugin/axios"
import {sanitize}           from "~/utils/helpers"
import {getAxiosAuth}       from "~/utils/axiosAuth"

export default {
    name: "Settings",
    mixins: [ErrorHandler],
    metaInfo: {
        title: "General Settings"
    },
    data: () => ({
        app: {} as Meta,
        socials: [] as Social[],
        brands: ["facebook", "youtube", "twitter", "whatsapp", "snapchat", "mail", "instagram"],
        processing: false
    }),
    mounted() {
        const app = this.$store.getters["app/config"] as Meta
        if (app) this.app = cloneDeep(app)
        const socials = this.$store.getters["settings/socials"] as Social[]
        if (isArray(socials)) this.socials = cloneDeep(socials)
    },
    methods: {
        deleteLink(index) {
            this.socials.splice(index, 1)
        },
        addLink() {
            this.socials.push({
                text: "",
                link: ""
            })
        },
        isSelected(text) {
            return this.socials.some((s) => s.text === text)
        },
        validate(): boolean {
            const invalid_fields = []
            Object.entries(this.app).forEach((v: [string, string]) => {
                if (sanitize(v[1])) {
                    invalid_fields.push(v[0])
                }
            })

            this.socials.forEach((social) => {
                if (sanitize(social.link)) {
                    invalid_fields.push(social.text)
                }
            })

            if (invalid_fields.length > 0) {
                let multiple = invalid_fields.length > 1 ? "fields were" : "field is"
                let attribute = invalid_fields.join(", ")
                toast(
                    `${attribute} ${multiple} invalid. Only text is allowed.`,
                    "error"
                )
                return false
            }

            return true
        },
        async save() {

            if (!this.validate())
                return

            try {
                await axios.post("/settings", {
                    app: this.app,
                    socials: this.socials
                }, getAxiosAuth())

                await this.$store.dispatch("settings/updateSocials", cloneDeep(this.socials))
                await this.$store.dispatch("app/updateConfig", cloneDeep(this.app))

                toast("Update Settings.", "error")

            } catch (e) {
                this.handleAxiosError(e)
            } finally {
                this.processing = false
            }
        }
    }
}
</script>
