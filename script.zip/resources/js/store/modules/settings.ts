import Vue      from "vue"

export default {
	namespaced: true,
	state: () => ({
		menus: [] as Menu[],
		socials: [] as Social[],
		ads: [] as Ad[],
		headerCodeBlock: ""
	}),
	getters: {
		menus: (state) => state.menus,
		socials: (state) => state.socials,
		ads: (state) => state.ads,
		headerCodeBlock: (state) => state.headerCodeBlock
	},
	actions: {
		updateMenus: (state, payload: Menu[]) => state.commit("updateMenus", payload),
		updateSocials: (state, payload: Social[]) => state.commit("updateSocials", payload),
		updateAds: (state, payload: Ad[]) => state.commit("updateAds", payload),
		updateHeaderCodeBlock: (state, payload: string) => state.commit("updateHeaderCodeBlock", payload)
	},
	mutations: {
		updateMenus: (state, payload: Menu[]) => {
			Vue.set(state, "menus", payload)
		},
		updateSocials: (state, payload: Social[]) => {
			Vue.set(state, "socials", payload)
		},
		updateAds: (state, payload: Ad[]) => {
			Vue.set(state, "ads", payload)
		},
		updateHeaderCodeBlock: (state, payload: string) => {
			Vue.set(state, "headerCodeBlock", payload)
		}
	}
}

export type Social = {
	text?: string
	link?: string
}
export type Menu = {
	id: number
	text: string
	link: string
	external: boolean
}
export type Ad = {
	status: string | "enabled" | "disabled"
	network: string
	code: string
	name?: string
}
