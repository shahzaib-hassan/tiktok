import axios     from "~/plugin/axios"
import {isArray} from "lodash-es"
import Vue       from "vue"

export default {
    namespaced: true,
    state: () => ({
        pages: [] as Page[],
        loading: false
    }),
    getters: {
        pages: (state) => state.pages,
        loading: (state) => state.loading,
        page: (state) => (slug: string) => state.pages.find((page) => page.slug === slug)
    },
    actions: {
        setPages({commit}, payload: Page[]) {
            return commit("setPages", payload)
        },
        async loadPages({commit}) {
            try {
                commit("setLoading", true)
                const {data} = await axios.get<{ pages: Page[] }>("pages")
                if (isArray(data.pages))
                    commit("setPages", data.pages)
            } catch (e) {
                // .
            } finally {
                commit("setLoading", false)
            }
        },
        updatePage({commit}, payload: Page) {
            commit("updatePage", payload)
        }
    },
    mutations: {
        setPages(state, payload: Page[]) {
            Vue.set(state, "pages", payload)
        },
        setLoading(state, payload: boolean) {
            Vue.set(state, "loading", payload)
        },
        updatePage(state, payload: Page) {
            const pages = state.pages as Page[]
            const idx = pages.findIndex((p) => p.slug === payload.slug)
            if (idx === -1) return
            Vue.set(state.pages, idx, payload)
        }
    }
}

export type Page = {
    id: number
    title: string
    slug: string
    excerpt: string
    body: string
    created_at?: number
    updated_at?: number
}
