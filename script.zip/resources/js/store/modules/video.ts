import Vue           from "vue"
import {notify}      from "~/utils/notification"
import axios         from "~/plugin/axios"
import {handleError} from "~/utils/handleError"

export default {
    namespaced: true,
    state: () => ({
        video: null as Video,
        loading: false,
        isSingle: true,
        recent: [] as Video[],
        trending: [] as Video[]
    }),
    getters: {
        video: (state) => state.video,
        loading: (state) => state.loading,
        isSingle: (state) => state.isSingle,
        recent: (state) => state.recent,
        trending: (state) => state.trending
    },
    actions: {
        setVideo({commit}, payload: Video) {
            return commit("setVideo", payload)
        },
        setLoading({commit}, payload: boolean) {
            return commit("setLoading", payload)
        },
        setIsSingle({commit}, payload: boolean) {
            return commit("setIsSingle", payload)
        },
        setRecent({commit}, payload: Video[]) {
            return commit("setRecent", payload)
        },
        setTrending({commit}, payload: Video[]) {
            return commit("setTrending", payload)
        },
        async search(store, url: string, isSingle: boolean = false) {
            url = url.trim().replace(/^https?/, "https")

            if (!validate(url))
                return notify("URL is invalid!")

            await store.commit("setLoading", true)

            //ADD HTTPS TO URL
            if (!/^https?/.test(url))
                url = `https://${url}`

            url = url.split('?')[0]

            try {
                let {data} = await axios.get<{ video: Video }>(`v1/tiktok-video`, {params: {url}})
                if (!data?.video?.user || !data?.video?.stats || !data?.video?.cover) {
                    throw new Error("Something went wrong while scraping the video.")
                }

                store.commit("setIsSingle", isSingle)
                store.commit("setVideo", data.video)

            } catch (e) {
                handleError(e, true)
            } finally {
                store.commit("setLoading", false)
            }
        }
    },
    mutations: {
        setVideo(state, payload: Video) {
            Vue.set(state, "video", payload)
        },
        setLoading(state, payload: boolean) {
            Vue.set(state, "loading", payload)
        },
        setIsSingle(state, payload: boolean) {
            Vue.set(state, "isSingle", payload)
        },
        setRecent(state, payload: Video[]) {
            Vue.set(state, "recent", payload)
        },
        setTrending(state, payload: Video[]) {
            Vue.set(state, "trending", payload)
        }
    }
}

function validate(url: string): boolean {
    return /^(https?:\/\/)?(www\.)?vm\.tiktok\.com\/[^\n]+\/?$/.test(url)
        || /^(https?:\/\/)?(www\.)?m\.tiktok\.com\/v\/[^\n]+\.html([^\n]+)?$/.test(url)
        || /^(https?:\/\/)?(www\.)?tiktok\.com\/@[^\n]+\/video\/[^\n]+$/.test(url)
        || /^(https?:\/\/)?(www\.)?vt\.tiktok\.com\/[^\n]+\/?$/.test(url)
}

export type Video = {
    id: number
    video_id: string
    title: string
    caption: string
    cover: string
    dl_count: number
    url: string
    url_nwm?: string
    music?: Video.Music
    user?: Video.User
    stats?: Video.Stats
    uploaded_at?: string
    video_url?: string
    share_url?: string
}

export namespace Video {
    export type Music = {
        id?: number
        title?: string
        author?: string
        cover?: string
        url?: string
    }
    export type User = {
        name: string
        username: string
        cover: string
    }
    export type Stats = {
        shares: number
        likes: number
        comments: number
        play?: number
    }
}
