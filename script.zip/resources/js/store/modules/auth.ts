import Vue            from "vue"
import cookies        from "js-cookie"
import router         from "~/routes"
import axios          from "~/plugin/axios"
import {toast}        from "~/utils/toast"
import {handleError}  from "~/utils/handleError"
import {getAxiosAuth} from "~/utils/axiosAuth"

const state = () => ({
    user: null as User,
    processing: false
})

const getters = {
    user: (state) => state.user as User,
    processing: (state) => state.processing
}

const actions = {
    async login({state, commit}, {email, password}: LoginPayload) {
        try {
            commit("setProcessing", true)
            const {data} = await axios.post<{ user: User, token: string }>("login", {email, password})
            //Get User
            Vue.set(state, "user", data.user)
            //Set Access Token
            cookies.set("token", data.token)

            toast("LoggedIn! Redirecting in a moment", "success")

            //Redirect in 2 sec
            setTimeout(() => {
                router.push({name: "admin.dashboard"})
            }, 2000)

        } catch (e) {
            handleError(e)
        } finally {
            commit("setProcessing", false)
        }
    },
    async loginWithToken({commit}, token: string) {
        try {

            commit("setProcessing", true)

            const {data} = await axios.get<{ user: User }>("/me", {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            })

            if (data.user)
                commit("updateUser", data.user)
            else cookies.remove("token")

        } catch (e) {
            //.
            cookies.remove("token")
        } finally {
            commit("setProcessing", false)
        }
    },
    updateUser({commit}, payload: User) {
        return commit("updateUser", payload)
    },
    async logout({commit}) {
        try {
            await axios.post("/logout", null, getAxiosAuth())
            cookies.remove("token")
            commit("updateUser", null)
        } catch (e) {
            //.
        }
    }
}

const mutations = {
    setProcessing(state, payload: boolean) {
        state.processing = payload
    },
    updateUser(state, payload: User) {
        return Vue.set(state, "user", payload)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}


export type User = {
    id: number
    fname?: string
    lname?: string
    full_name?: string
    email: string
    role: string | "admin" | "demo"
    isAdmin: boolean
}

type LoginPayload = {
    email: string
    password: string
}
