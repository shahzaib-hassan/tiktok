import {toast}        from "~/utils/toast"
import axios          from "~/plugin/axios"
import {handleError}  from "~/utils/handleError"
import {getAxiosAuth} from "~/utils/axiosAuth"

export default {
    methods: {
        async uploadImage(file: File, Editor, cursorLocation, resetUploader) {

            toast("Image Uploading", "info")

            try {
                this.processing = true

                const formData = new FormData()
                formData.append("image", file, file.name)

                const {data} = await axios.post<{ image: string }>("/pages/image-upload", formData, getAxiosAuth())
                Editor.insertEmbed(cursorLocation, "image", data.image)

                toast("Image Uploaded", "success")
                resetUploader()
            } catch (e) {
                handleError(e)
            } finally {
                this.processing = false
            }
        }
    }
}
