import PerfectScrollbar from "perfect-scrollbar"
import {Video}          from "~/store/modules/video"
import {mapActions}     from "vuex"

export default {
    data: () => ({
        ps: null as PerfectScrollbar,
        loading: false
    }),
    watch: {
        "records": {
            immediate: true,
            handler() {
                if (this.ps)
                    this.ps.update()
            }
        }
    },
    computed: {
        records(): Video[] {
            return this.$store.getters[this.getter]
        }
    },
    mounted() {
        this.ps = new PerfectScrollbar(this.$refs[this.ref_item], {
            wheelSpeed: 2,
            wheelPropagation: true,
            suppressScrollX: true
        })
    },
    destroyed() {
        this.ps?.destroy()
        this.ps = null
    },
    methods: {
        ...mapActions({
            "search": "video/search"
        }),
        async openVideo(video: Video) {
            await this.search(video.video_url, false)
        },
        loadVideos() {
            // Implement Me.
        }
    }
}
