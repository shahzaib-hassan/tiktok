import {mapActions} from "vuex"
import {notify}     from "~/utils/notification"
import {toast}      from "~/utils/toast"

export default {
    data: () => ({
        searchQuery: "",
        processing: false,
        isSingle: true
    }),
    computed: {
        canPaste() {
            return window.navigator.clipboard !== undefined
        }
    },
    methods: {
        ...mapActions({
            "setVideo": "video/setVideo",
            "setIsSingle": "video/setIsSingle",
            "search": "video/search"
        }),
        paste() {
            window.navigator.clipboard.readText().then(text => {
                this.searchQuery = text
            }).catch(e => {
                toast(e.message)
            })
        },
        async searchVideo() {
            if (this.search === "")
                return notify("Please enter something!")

            try {
                this.processing = true
                await this.search(this.searchQuery, this.isSingle)
            } catch (e) {
                // .
            } finally {
                this.processing = false
            }
        }
    }
}
