import {AxiosError}  from "axios"
import {toast}       from "~/utils/toast"
import {handleError} from "~/utils/handleError"

export default {
    methods: {
        handleAxiosError(error: AxiosError<{ message: string }>) {
            return handleError(error)
        }
    }
}
