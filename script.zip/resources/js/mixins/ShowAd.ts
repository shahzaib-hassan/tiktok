import {isString} from "lodash-es"

export default {
    computed: {
        shouldShowAd() {
            return true
            // return !isString(this.$store.getters["video/video"]?.video_id) && window.screen.width > 320
        }
    }
}
