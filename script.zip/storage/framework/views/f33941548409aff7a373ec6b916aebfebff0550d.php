<section id="success" class="center none">
    <span class="icon-check icon-lg"></span>
    <h2 class="title">Success!</h2>
    <p>Application has been installed successfully!</p>
    <div class="go">
        <a href="/" class="oval button">Login</a>
    </div>
</section>
<?php /**PATH /Volumes/projects/www/tiktok-downloader/resources/views/install/step-success.blade.php ENDPATH**/ ?>