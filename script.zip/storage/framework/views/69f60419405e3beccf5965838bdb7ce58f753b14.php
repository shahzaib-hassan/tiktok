<?php
    $installable = true;
?>

<section id="requirements" class="center none">

    <div class="sub-section">

        <h3 class="section-title">
            1. Please configure PHP to match following requirements / settings:
        </h3>

        <table>
            <thead>
            <tr>
                <th>PHP Settings</th>
                <th>Required</th>
                <th>Current</th>
                <th class="status">&nbsp;</th>
            </tr>
            </thead>

            <tbody>
            <tr>
                <td><span class="fw-700">PHP Version</span></td>
                <td>7.2.0+ (7.2.5+ Recommended)</td>
                <td><?php echo e(PHP_VERSION); ?></td>
                <td class="status">
                    <?php if(version_compare(PHP_VERSION, '7.2.0') >= 0): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <td><span class="fw-700">allow_url_fopen</span></td>
                <td>On</td>
                <td><?php echo e(ini_get("allow_url_fopen") ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if(ini_get("allow_url_fopen")): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="sub-section">
        <h3 class="section-title">
            2. Please make sure following extensions are installed and enabled:
        </h3>

        <table>
            <thead>
            <tr>
                <th>Name</th>
                <th>Required</th>
                <th>Current</th>
                <th class="status">&nbsp;</th>
            </tr>
            </thead>

            <tbody>
            <tr>
                <?php $curl = function_exists("curl_version") ? curl_version() : false; ?>
                <td><span class="fw-700">cURL</span></td>
                <td>7.55.0+</td>
                <td><?php echo e(!empty($curl["version"]) ? $curl["version"] : "Not installed"); ?></td>
                <td class="status">
                    <?php if(!empty($curl["version"]) && version_compare($curl["version"], '7.55') >= 0): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php
                    $openssl = extension_loaded('openssl');
                    if ($openssl && !empty(OPENSSL_VERSION_NUMBER)) {
                        $installed_openssl_version = get_openssl_version_number(OPENSSL_VERSION_NUMBER);
                    }
                ?>
                <td><span class="fw-700">OpenSSL</span></td>
                <td>1.0.2k+</td>
                <td><?php echo e(!empty($installed_openssl_version) ? $installed_openssl_version : "Outdated or not installed"); ?></td>
                <td class="status">
                    <?php if(!empty($installed_openssl_version) && $installed_openssl_version >= "1.0.2k"): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php
                    $pdo = defined('PDO::ATTR_DRIVER_NAME');
                ?>
                <td><span class="fw-700">PDO</span></td>
                <td>On</td>
                <td><?php echo e($pdo ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($pdo): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php $mysqli = function_exists('mysqli_connect') ?>
                <td><span class="fw-700">mysqli</span></td>
                <td>On</td>
                <td><?php echo e($mysqli ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($mysqli): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php $gd = extension_loaded('gd') && function_exists('gd_info'); ?>
                <td><span class="fw-700">GD</span></td>
                <td>On</td>
                <td><?php echo e($gd ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($gd): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php $mbstring = extension_loaded('mbstring') && function_exists('mb_get_info'); ?>
                <td><span class="fw-700">mbstring</span></td>
                <td>On</td>
                <td><?php echo e($mbstring ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($mbstring): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php $json = extension_loaded('json') && function_exists('json_decode'); ?>
                <td><span class="fw-700">json</span></td>
                <td>On</td>
                <td><?php echo e($json ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($json): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>

            <tr>
                <?php $exif = function_exists('exif_read_data'); ?>
                <td><span class="fw-700">EXIF</span></td>
                <td>On</td>
                <td><?php echo e($exif ? "On" : "Off"); ?></td>
                <td class="status">
                    <?php if($exif): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="sub-section">
        <h3 class="section-title">
            3. Please make sure following files and directories are writable:
        </h3>

        <table>
            <thead>
            <tr>
                <th>Directory</th>
                <th class="status">&nbsp;</th>
            </tr>
            </thead>

            <tbody>

            <?php
                $settings_writable = \Illuminate\Support\Facades\File::isWritable(storage_path('/app'));
            ?>

            <tr>
                <td><span class="fw-700">/storage/app/</span></td>
                <td class="status">
                    <?php if($settings_writable): ?>
                        <span class="icon-check"></span>
                    <?php else: ?>
                        <span class="icon-error"></span>
                        <?php $installable = false; ?>
                    <?php endif; ?>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <button <?php echo e($installable ? '' : 'disabled'); ?> class="mt-40">Next</button>
</section>
<?php /**PATH /Volumes/projects/www/tiktok-downloader/resources/views/install/step-requirements.blade.php ENDPATH**/ ?>