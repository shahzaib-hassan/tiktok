<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Upgrade - <?php echo e(config('app.name')); ?></title>

    <link rel="stylesheet" href="/css/theme/light.css">

    <?php echo $__env->make("install.style", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<main>
    <div class="logo">
        <img src="/imgs/logos/logo-wide.png" alt="TikTokInstaller">
    </div>

    <?php echo $__env->make("upgrade.step-welcome", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("upgrade.step-requirements", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("upgrade.step-install", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("upgrade.step-success", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("upgrade.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>
</body>
</html>
<?php /**PATH /Volumes/projects/www/tikdown/resources/views/upgrade.blade.php ENDPATH**/ ?>