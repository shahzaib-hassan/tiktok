<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off'): ?>
        <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <?php endif; ?>

    <title><?php echo e(meta('title')); ?></title>
    <base href="<?php echo e(config('app.url')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('imgs/favicon.jpg')); ?>" type="image/jpg">

    <meta name="description" content="<?= meta('description') ?>">
    <meta name="keywords" content="<?= meta('keywords') ?>">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@300;400;500;700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/solid.min.css" integrity="sha512-tk4nGrLxft4l30r9ETuejLU0a3d7LwMzj0eXjzc16JQj+5U1IeVoCuGLObRDc3+eQMUcEQY1RIDPGvuA7SNQ2w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/brands.min.css" integrity="sha512-sVSECYdnRMezwuq5uAjKQJEcu2wybeAPjU4VJQ9pCRcCY4pIpIw4YMHIOQ0CypfwHRvdSPbH++dA3O4Hihm/LQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.0/css/regular.min.css" integrity="sha512-oVLhs3nuzwtrU1koPaammbNKBVk8yM0Bx9QekKb8P7NO233VBOJuWkHSmkp6ZWXCzs9bTidZVNrYg3O58hRUrw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/fontawesome.min.css" integrity="sha512-P9vJUXK+LyvAzj8otTOKzdfF1F3UYVl13+F8Fof8/2QNb8Twd6Vb+VD52I7+87tex9UXxnzPgWA3rH96RExA7A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!--GLOBAL STYLE: BEGIN-->
    <?php
        $appTheme = config('app.theme');
    ?>

    <link rel="stylesheet" href="<?php echo e(mix('/css/app.css')); ?>">
    <?php if($appTheme === 'light'): ?>
        <link rel="stylesheet" href="<?php echo e(mix('/css/theme/light.css')); ?>">
    <?php elseif($appTheme === 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(mix('/css/theme/dark.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(mix('/css/theme/dark.css')); ?>"
              media="(prefers-color-scheme: dark)">
        <link rel="stylesheet" href="<?php echo e(mix('/css/theme/light.css')); ?>"
              media="(prefers-color-scheme: light)">
<?php endif; ?>

<!-- SOCIAL META TAGS: BEGIN -->
    <meta property="og:title" content="<?php echo e(meta('title')); ?>">
    <meta property="og:description" content="<?php echo e(meta('description')); ?>">
    <meta property="og:image" content="<?php echo e(asset(meta('cover'))); ?>">
    <meta property="og:url" content="<?php echo e(meta('url')); ?>">
    <meta name="twitter:card" content="<?php echo e(asset(meta('cover'))); ?>">
    <!-- SOCIAL META TAGS: END -->
</head>
<body>
<div id="app" data-page="<?php echo e((string)pageData()); ?>">
</div>
<?php echo $__env->make('components.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script defer src="<?php echo e(mix('/js/manifest.js')); ?>"></script>
<script defer src="<?php echo e(mix('/js/vendor.js')); ?>"></script>
<script defer src="<?php echo e(mix('/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Volumes/projects/www/tiktok-downloader/resources/views/app.blade.php ENDPATH**/ ?>