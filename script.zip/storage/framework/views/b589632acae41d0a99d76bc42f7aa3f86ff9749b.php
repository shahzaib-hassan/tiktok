<section id="welcome" class="center show">
    <h1><?php echo e(config('app.name')); ?> Upgrade</h1>
    <p>Welcome! <?php echo e(config('app.name')); ?> is an online web scraper which allows you to scrape TikTok video links to
        download
        Videos without watermark</p>
    <p class="mb-40"><b>Upgrade process is very easy and it takes less than 2 minutes!</b></p>
    <button>
        Start Upgrade
    </button>
</section>
<?php /**PATH /Volumes/projects/www/tiktok-downloader/resources/views/upgrade/step-welcome.blade.php ENDPATH**/ ?>