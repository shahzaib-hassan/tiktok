<?php echo $__env->make("install.script-core", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>

    const Lite = {};

    Lite.InstallerWizard = class InstallerWizard {

        steps = {
            1: '#welcome',
            2: '#agreement',
            3: '#requirements',
            4: '#install',
            5: '#success'
        }
        current_step = 1;

        constructor() {
            this.stepOne()
        }

        stepOne() {
            let next = $(`${this.steps[1]} button`);
            next.bind('click', () => {
                this.transite(2, [
                    () => {
                        $('.logo').classList.add('min')
                    },
                    this.stepTwo.bind(this)
                ]);
            })
        }

        stepTwo() {
            //Get Elements
            let next = $(`${this.steps[2]} button`);
            let agree = $(`${this.steps[2]} #agree`);
            //Default to true
            next.disabled = true;
            //Add Event
            agree.bind('change', () => {
                next.disabled = !agree.checked
            })

            next.bind('click', () => {
                this.transite(3, this.stepThree.bind(this))
            })
        }

        stepThree() {
            let next = $(`${this.steps[3]} button`);
            if (!next.disabled)
                next.bind('click', () => {
                    this.transite(4, this.stepFour.bind(this))
                })
        }

        stepFour() {
            let finish = $(`${this.steps[4]} form`)

            finish.bind('submit', this.install.bind(this))
            document.installer.db_driver?.addEventListener('change', (e) => {
                const target = e.target
                document.installer.db_port.value = target.value === 'pgsql' ? 5432 : 3306
            })
        }


        async install(e) {
            e.preventDefault();

            /**
             * @type  {HTMLFormElement} form
             */
            const form = document.installer;

            const formData = {
                license: form.license.value,
                app: {
                    name: form.app_name.value,
                    url: form.app_url.value,
                },
                db: {
                    driver: form.db_driver.value,
                    host: form.db_host.value,
                    port: Number(form.db_port.value),
                    database: form.db_name.value,
                    username: form.db_username.value,
                    password: form.db_password.value,
                    prefix: form.db_tablePrefix.value
                },
                user: {
                    f_name: form.user_fName.value,
                    l_name: form.user_lName.value,
                    email: form.user_email.value,
                    password: form.user_password.value
                }
            }


            try {
                this.loading(true)

                const res = await post("/api/install", formData)
                if (res.status !== 200)
                    throw new Error(res.data.message)

                this.error('', false)

                this.transite(5, () => {
                    $('.logo').classList.remove('min')
                });

            } catch (e) {
                this.error(e.message)
            } finally {
                this.loading(false)
            }
        }


        loading(show = true) {
            let body = $('body')
            if (!body) return
            if (show)
                body.classList.add('on-progress')
            else body.classList.remove('on-progress')
        }

        error(error, show = true) {
            let errorText = $(`${this.steps[4]} .form-errors`)

            if (errorText) {

                if (!show) {
                    errorText.classList.remove('show')
                    errorText.innerText = ''
                    return
                }

                errorText.classList.add('show')
                if (typeof error === 'object') {
                    error.innerText = ''
                    Object.values(error).forEach(value => {
                        error.innerText += value + "<br/>"
                    })
                } else
                    errorText.innerText = error

                window.scrollTo(0, 0)
            }
        }


        /**
         * Transite
         * @param  {number} to
         * @param  {*} callback
         */
        transite(to, callback = null) {
            transition(`${this.steps[this.current_step]}`,
                `${this.steps[to]}`, callback);
            this.current_step = to;
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        //Start Installer
        new Lite.InstallerWizard();
    })
</script>
<?php /**PATH /Volumes/projects/www/tiktok-downloader/resources/views/install/script.blade.php ENDPATH**/ ?>