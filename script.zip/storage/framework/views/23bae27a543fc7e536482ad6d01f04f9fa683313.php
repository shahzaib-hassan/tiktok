<?php
    /**
     * @var Collection<int, Page> $pages
     * @var Page $page
     */use App\Models\Page;use Illuminate\Support\Collection;

?>

<?php echo '<?xml version = "1.0" encoding = "UTF-8"?>'; ?>

<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
            <loc><?php echo e(rtrim(config('app.url'), '/') . '/page/' . $page->slug); ?></loc>
            <changefreq>daily</changefreq>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH /Volumes/projects/www/tikdown/resources/views/sitemap.blade.php ENDPATH**/ ?>