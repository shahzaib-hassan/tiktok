const mix = require("laravel-mix")
const path = require("path")
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
require('laravel-mix-polyfill')

mix.options({
    fileLoaderDirs: {
        fonts: "../fonts"
    }, vue: {
        runtimeOnly: true
    },
})

mix.setPublicPath(`public`)

mix.webpackConfig({
    plugins: [// new BundleAnalyzerPlugin()
    ], resolve: {
        alias: {
            "~": path.resolve(__dirname, 'resources/js'),
            "Components": path.resolve(__dirname, 'resources/js/Components'),
            'styles': path.resolve(__dirname, 'resources/css'),
        }
    },
})

mix.ts("resources/js/app.ts", "js")
    .vue({version: 2})
    .extract()
    .polyfill({
        enabled: true,
        useBuiltIns: "usage",
        targets: "firefox 50, IE 11"
    })

mix.sass("resources/css/app.scss", "css")
    .sass("resources/css/theme/light.scss", "css/theme")
    .sass("resources/css/theme/dark.scss", "css/theme")
    .version()
